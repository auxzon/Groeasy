import 'package:google_fonts/google_fonts.dart';

var Font1 = GoogleFonts.aBeeZeeTextTheme();
