import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/Cart/CartScreen.dart';
import 'package:auxzonfoodapp/view/HomeScreen/HomeScreen.dart';
import 'package:auxzonfoodapp/view/Profile/Profile.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';

import '../../../view/Category/categoryscreen.dart';

class BottomNavigationBarController extends GetxController {
  BottomNavigationBarController({required this.index});
  final int index;
  late PersistentTabController navcontroller;

  List<Widget> screens = [
    const HomeScreen(),
    const Cartscreen(),
    const CategoryScreen(),
    const Myaccount(),
  ];

  List<PersistentBottomNavBarItem> navItems = [
    PersistentBottomNavBarItem(
      icon: const Icon(Icons.home),
      title: ("Home"),
      activeColorPrimary: bottombarselectedcolor,
      inactiveColorPrimary:bottombarnotselectedcolor,
    ),
    PersistentBottomNavBarItem(
      icon: const Icon(Icons.local_grocery_store),
      title: ("Cart"),
      activeColorPrimary: bottombarselectedcolor,
      inactiveColorPrimary:bottombarnotselectedcolor,
    ),
    PersistentBottomNavBarItem(
      icon: const Icon(Icons.shopping_bag),
      title: ("Category"),
      activeColorPrimary: bottombarselectedcolor,
      inactiveColorPrimary:bottombarnotselectedcolor,
    ),
    PersistentBottomNavBarItem(
      icon: const Icon(Icons.person),
      title: ("Profile"),
      activeColorPrimary: bottombarselectedcolor,
      inactiveColorPrimary:bottombarnotselectedcolor,
    ),
  ];
  // hide bottom sheet

  var hidebtmsheet = true.obs;
  HideBtmSheet(){
    hidebtmsheet.value = false;
  }
  @override
  void onInit() {
    navcontroller = PersistentTabController(initialIndex: index);
    hidebtmsheet.value = true;
    super.onInit();
  }
}
