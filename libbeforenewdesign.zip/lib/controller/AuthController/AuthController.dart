import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../view/Auth/LoginScreen.dart';
import '../../view/Common/BottomSheet/BottomSheet.dart';

class AuthController extends GetxController {
  AuthController({required this.context});
  var isLoading = false.obs;

  final BuildContext context;
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final regemail = TextEditingController();
  final regpasswordController = TextEditingController();
  final regconfirmPasswordController = TextEditingController();

  final GetStorage _storage = GetStorage();

  var showpasslg = false.obs;
  var showpassrg = false.obs;

  logtogglepass() {
    showpasslg.value = !showpasslg.value;
  }

  regtogglepass() {
    showpassrg.value = !showpassrg.value;
  }

  void login() {
    if (_validateLogin()) {
      isLoading.value = true;
      Future.delayed(Duration(seconds: 2), () {
        isLoading.value = false;
        _storage.write('isLoggedIn', true);

        Get.snackbar('Success', 'Login Successful',
            colorText: Theme.of(context).colorScheme.surface);
        Navi.to(BottomNavigator(index: 0));
      });
    }
  }

  void logout() {
    _storage.write('isLoggedIn', false);
  }

  void register() {
    if (_validateRegister()) {
      isLoading.value = true;
      Future.delayed(Duration(seconds: 2), () {
        isLoading.value = false;
        Get.snackbar('Success', 'Registration Successful',
            colorText: Theme.of(context).colorScheme.surface);
        Navi.to(LoginScreen());
      });
    }
  }

  bool _validateLogin() {
    if (emailController.text.isEmpty || passwordController.text.isEmpty) {
      Get.snackbar('Error', 'All fields are required',
          colorText: Theme.of(context).colorScheme.surface);
      return false;
    }
    return true;
  }

  bool _validateRegister() {
    if (regemail.text.isEmpty ||
        regpasswordController.text.isEmpty ||
        regconfirmPasswordController.text.isEmpty) {
      Get.snackbar('Error', 'All fields are required',
          colorText: Theme.of(context).colorScheme.surface);
      return false;
    }
    if (regpasswordController.text != regconfirmPasswordController.text) {
      Get.snackbar('Error', 'Passwords do not match',
          colorText: Theme.of(context).colorScheme.surface);
      return false;
    }
    return true;
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    regpasswordController.dispose();
    regemail.dispose();
    regconfirmPasswordController.dispose();
    super.dispose();
  }
}
