import 'package:get/get.dart';

class Orderscreencontroller extends GetxController {
  List<Map<String, dynamic>> orders = [
    {
      "orderNumber": 351,
      "orderDate": "23 Feb 2021, 08:28 PM",
      "items": [
        {
          "foodName": "Vegetable Mixups",
          "description": "Vegetable Fritters with Egg",
          "price": "5.30",
          "quantity": "1",
          "image": "images/food1.jpg"
        },
        {
          "foodName": "Prawn Mix Salad",
          "description": "Fresh Prawn mix salad",
          "price": "5.30",
          "quantity": "1",
          "image": "images/food2.jpg"
        }
      ],
    },
    {
      "orderNumber": 348,
      "orderDate": "23 Feb 2021, 08:28 PM",
      "items": [
        {
          "foodName": "Vegetable Mixups",
          "description": "Vegetable Fritters with Egg",
          "price": "5.30",
          "quantity": "1",
          "image": "images/food1.jpg"
        },
        {
          "foodName": "Prawn Mix Salad",
          "description": "Fresh Prawn mix salad",
          "price": "5.30",
          "quantity": "1",
          "image": "images/food2.jpg"
        }
      ],
    }
  ];
}
