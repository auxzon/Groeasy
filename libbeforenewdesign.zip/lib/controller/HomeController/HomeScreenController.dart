import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Homescreencontroller extends GetxController {
  List Hotelimglist = [
    "images/petcategory.jpg",
    "images/Bakerycat.jpg",
    "images/frozenfoodscat.png",
    "images/fruitcat.png",
    "images/milksploffercat.png",
    "images/farmfreshcat.png",
    "images/petcategory.jpg",
    "images/Bakerycat.jpg",
    "images/frozenfoodscat.png",
    "images/fruitcat.png",
    "images/milksploffercat.png",
    "images/farmfreshcat.png",
    "images/petcategory.jpg",
    "images/Bakerycat.jpg",
    "images/frozenfoodscat.png",
    "images/fruitcat.png",
    "images/milksploffercat.png",
    "images/farmfreshcat.png",
    "images/petcategory.jpg",
    "images/Bakerycat.jpg",
    "images/frozenfoodscat.png",
    "images/fruitcat.png",
    "images/milksploffercat.png",
    "images/farmfreshcat.png",
    "images/milksploffercat.png",
  ];

  List Hotelnamelist = [
    "Pet Stores",
    "Bakery",
    "Frozen Foods",
    "Fruits",
    "Milk Special Offer",
    "Farm Fresh",
    "Pet Stores",
    "Bakery",
    "Frozen Foods",
    "Fruits",
    "Milk Special Offer",
    "Farm Fresh",
    "Pet Stores",
    "Bakery",
    "Frozen Foods",
    "Fruits",
    "Milk Special Offer",
    "Farm Fresh",
    "Pet Stores",
    "Bakery",
    "Frozen Foods",
    "Fruits",
    "Milk Special Offer",
    "Farm Fresh",
    "Milk Special Offer",
  ];

  List Foodimglist = [
    "images/sugarimage.png",
    "images/saltimages.png",
    "images/Easterncorianderpowderimg.png",
    "images/L.Ghingpowderimage.png",
    "images/sugarimage.png",
    "images/saltimages.png",
    "images/Easterncorianderpowderimg.png",
    "images/L.Ghingpowderimage.png",
    "images/sugarimage.png",
    "images/saltimages.png",
    "images/Easterncorianderpowderimg.png",
    "images/L.Ghingpowderimage.png",
  ];

  List Foodtypelist = [
    "veg",
    "veg",
    "non veg",
    "non veg",
    "veg",
    "veg",
    "non veg",
    "non veg",
    "veg",
    "veg",
    "non veg",
    "non veg",
  ];

  List Foodnamelist = [
    "Sugar",
    "Salt",
    "Eastern Coriander Powder",
    "L.G Hing Powder",
    "Sugar",
    "Salt",
    "Eastern Coriander Powder",
    "L.G Hing Powder",
    "Sugar",
    "Salt",
    "Eastern Coriander Powder",
    "L.G Hing Powder",
  ];

  List Foodratelist = [
    "52",
    "61",
    "52",
    "92",
    "52",
    "61",
    "52",
    "92",
    "52",
    "61",
    "52",
    "92",
  ];

  List Foodratinglist = [
    "4.1",
    "4.2",
    "4.3",
    "4.4",
    "4.1",
    "4.2",
    "4.3",
    "4.4",
    "4.1",
    "4.2",
    "4.3",
    "4.4",
  ];

  ScrollController scrollController = ScrollController();
  ScrollController ListscrollController = ScrollController();
  var atTop = false.obs;
  var atBottom = false.obs;

  @override
  void onInit() {
    super.onInit();

    // Listen to the GridView's scroll controller
    scrollController.addListener(() {
      if (scrollController.position.atEdge) {
        if (scrollController.position.pixels == 0) {
          // At the top of GridView
          atTop.value = true;
          atBottom.value = false;
          print(
              "You are at the top of GridView: ${atTop.value}, ${atBottom.value}");
        } else {
          // At the bottom of GridView
          atBottom.value = true;
          atTop.value = false;
          print(
              "You are at the bottom of GridView: ${atTop.value}, ${atBottom.value}");
        }
      } else {
        // In between, reset values
        atTop.value = false;
        atBottom.value = false;
        print(
            "GridView scrolling in between: ${atTop.value}, ${atBottom.value}");
      }
    });

    // Listen to the ListView's scroll controller
    ListscrollController.addListener(() {
      // Reset values when scrolling in ListView
      if (ListscrollController.position.atEdge) {
        if (ListscrollController.position.pixels == 0) {
          // At the top of ListView
          print("At the top of ListView");
        } else {
          // At the bottom of ListView
          print("At the bottom of ListView");
        }
      } else {
        // Scrolling in between, reset GridView scroll states
        atTop.value = false;
        atBottom.value = false;
        print("ListView scrolling in between: Resetting GridView states");
      }
    });
  }

  @override
  void onClose() {
    scrollController.dispose();
    ListscrollController.dispose();
    super.onClose();
  }
}
