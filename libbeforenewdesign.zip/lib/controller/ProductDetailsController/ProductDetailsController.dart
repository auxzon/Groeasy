import 'package:get/get.dart';

class Productdetailscontroller extends GetxController {
  var productCount = 1.obs;

  void increaseCount() {
    if (productCount < 8) {
      productCount++;
    }
  }

  void decreaseCount() {
    if (productCount > 1) {
      productCount--;
    }
  }
}
