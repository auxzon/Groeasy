import 'package:get/get.dart';

class CategoryScreenController extends GetxController {
  var categories = [
    "Fruits",
    "Vegetables",
    "Herbs & Spices",
    "Milk",
  ];

  var hotDeals = [
    {"title": "Discount on Fruits", "imageUrl": "https://images.unsplash.com/photo-1488459716781-31db52582fe9?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    {"title": "Buy 1 Get 1 Vegetables", "imageUrl": "https://images.unsplash.com/photo-1458917524587-d3236cc8c2c8?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    {"title": "Milk Special Offer", "imageUrl": "https://images.unsplash.com/photo-1506617420156-8e4536971650?q=80&w=2023&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
  ];

  var categoriesByStore = [
    {"title": "Local Market", "imageUrl": "https://images.unsplash.com/photo-1579603998886-249dfa2d1df3?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    {"title": "Farm Fresh", "imageUrl": "https://images.unsplash.com/photo-1626895565809-fe18b81bace2?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    {"title": "Grocery Hub", "imageUrl": "https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    {"title": "Pet Stores", "imageUrl": "https://img.freepik.com/premium-photo/team-veterinarians-examines-sick-corgi-dog-using-stethoscope_179755-11080.jpg?w=1380"},
  ];

  var otherCategories = [
    {"title": "Bakery", "imageUrl": "https://images.unsplash.com/photo-1511018556340-d16986a1c194?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    {"title": "Snacks", "imageUrl": "https://images.unsplash.com/photo-1621939514649-280e2ee25f60?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    {"title": "Dairy Products", "imageUrl": "https://images.unsplash.com/photo-1630356090105-808ba2fe97f7?q=80&w=1933&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    {"title": "Beverages", "imageUrl": "https://images.unsplash.com/photo-1531062916849-ac6624741870?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    {"title": "Frozen Foods", "imageUrl": "https://images.unsplash.com/photo-1582359425634-e3ded9a93770?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
  ];
  var productData = {
    "Fruits": [
      {"title": "Apple", "imageUrl": "https://images.unsplash.com/photo-1551445523-324a0fdab051?q=80&w=1970&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
      {"title": "Banana", "imageUrl": "https://images.unsplash.com/photo-1543218024-57a70143c369?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    ],
    "Vegetables": [
      {"title": "Carrot", "imageUrl": "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
      {"title": "Broccoli", "imageUrl": "https://images.unsplash.com/photo-1533910063084-5b1b485d2c35?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"},
    ],
    // Add other categories and products
  };

  List<Map<String, String>> getProductsForCategory(String categoryName) {
    return productData[categoryName] ?? [];
  }
}
