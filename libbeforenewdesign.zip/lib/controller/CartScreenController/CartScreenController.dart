import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CartScrennController extends GetxController {
  List Foodnamelist = [
    "Rice",
    "Wheat Flour",
    "Cooking Oil",
    "Sugar",
    "Salt",
    "Pulses (Lentils)",
    "Spices Mix",
    "Vegetable Oil",
    "Milk",
    "Eggs",
    "Butter",
    "Cheese",
  ];
  List FoodQtylist = [
    "1",
    "2",
    "3",
    "4",
    "1",
    "2",
    "3",
    "4",
    "1",
    "2",
    "3",
    "4",
  ];
  List Foodimglist = [
    "images/rice.jpg",
    "images/Wheat Flour.jpg",
    "images/Cooking Oil.jpg",
    "images/Sugar.jpg",
    "images/Salt.jpg",
    "images/Pulses (Lentils).jpg",
    "images/Spices Mix.jpg",
    "images/Vegetable Oil.jpg",
    "images/Milk.jpg",
    "images/Eggs.jpg",
    "images/Butter.jpg",
    "images/Cheese.jpg",
  ];
  List Hotelnamelist = [
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
  ];
  List Foodratelist = [
    "155",
    "255",
    "355",
    "455",
    "155",
    "255",
    "355",
    "455",
    "155",
    "255",
    "355",
    "455",
  ];

  List Foodratinglist = [
    "4.1",
    "4.2",
    "4.3",
    "4.4",
    "4.1",
    "4.2",
    "4.3",
    "4.4",
    "4.1",
    "4.2",
    "4.3",
    "4.4",
  ];
}
