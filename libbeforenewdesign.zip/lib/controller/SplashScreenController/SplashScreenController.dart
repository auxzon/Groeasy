import 'package:auxzonfoodapp/view/Auth/LoginScreen.dart';
import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../view/Common/BottomSheet/BottomSheet.dart';
import '../../view/HomeScreen/HomeScreen.dart';

class SplashScreenController extends GetxController {
  navigatetohome() {
    final GetStorage storage = GetStorage();

    bool isLoggedIn = storage.read('isLoggedIn') ?? false;
    Future.delayed(
      Duration(seconds: 2),
      () {
        Navi.to(isLoggedIn ? BottomNavigator(index: 0) : LoginScreen(),);
      },
    );
  }

  @override
  void onInit() {
    navigatetohome();
    // TODO: implement onInit
    super.onInit();
  }
}
