import 'package:auxzonfoodapp/controller/HomeController/HomeScreenController.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/view/Category/categoryscreen.dart';
import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:auxzonfoodapp/view/Common/ProductDetailsPage/ProductDetailsPage1.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:get/get.dart';

import '../../utils/color.dart';
import '../Common/BottomSheet/BottomSheet.dart';

class CategoryDetailsScreen extends StatelessWidget {
  final String categoryName;
  final List<Map<String, String>> products;

  const CategoryDetailsScreen({
    required this.categoryName,
    required this.products,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
      appBar: AppBar(
        forceMaterialTransparency: true,
        automaticallyImplyLeading: false,
        leading: IconButton(
            onPressed: () {
              Get.delete<Homescreencontroller>();
              Navi.to(BottomNavigator(
                index: 2,
              ),transition: Transition.leftToRight);
            },
            icon: Icon(Icons.arrow_back_ios_new)),
        title: Text(
          categoryName,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: products.length,
        itemBuilder: (context, index) {
          var product = products[index];
          return GestureDetector(
            onTap: () {
              Navi.to(Productdetailspage1(
                  name: "Sugar",
                  image: "images/Sugar.jpg",
                  rate: 45,
                  rating: "4.1"));
            },
            child: ProductCard(
              title: product['title']!,
              imageUrl: product['imageUrl']!,
            ),
          );
        },
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final String title;
  final String imageUrl;

  const ProductCard({
    required this.title,
    required this.imageUrl,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      color: liteColor,
      child: Row(
        children: [
          ClipRRect(
            borderRadius:
                const BorderRadius.horizontal(left: Radius.circular(12)),
            child: CachedNetworkImage(
              imageUrl: imageUrl,
              width: 100,
              height: 100,
              fit: BoxFit.cover,
              placeholder: (context, url) => const Center(
                child: CircularProgressIndicator(),
              ),
              errorWidget: (context, url, error) => Container(
                color: Colors.grey[300],
                child: const Icon(
                  Icons.broken_image,
                  size: 50,
                  color: Colors.grey,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }
}
