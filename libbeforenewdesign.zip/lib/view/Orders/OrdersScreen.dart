import 'package:auxzonfoodapp/controller/OrderScreenController/OrderScreenController.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/view/Common/CommonAppbar/CommonAppbar.dart';
import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:auxzonfoodapp/view/widgets/OrdersScreen/OrderAppBar/OrderScreenAppbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../../controller/BootomSheetController/Controller/BottomNavgationBarController.dart';
import '../../controller/HomeController/HomeScreenController.dart';
import '../../main.dart';
import '../../utils/color.dart';
import '../Common/BottomSheet/BottomSheet.dart';
import '../widgets/CartScreen/CustomCartProductcard/CustomCartProductCard.dart';
import '../widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import '../widgets/OrdersScreen/OrderScreenCard/OrdersScreenwidget.dart';

class Ordersscreen extends StatelessWidget {
  const Ordersscreen({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(Orderscreencontroller());
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        SystemNavigator.pop();
      },
      child: BaseScreen(
          child: Column(
        children: [
          CommonAppbar(
            title: "Orders",
            titlecolor: Theme.of(context).colorScheme.primary,
            leftcolor: Theme.of(context).colorScheme.primary,
            leftonTap: () {
                Get.delete<BottomNavigationBarController>();
                Get.delete<Homescreencontroller>();
                Navi.to(BottomNavigator(
                  index: 3,
                ),transition: Transition.leftToRight);
            },
          ),
          Expanded(
              child: ListView.builder(
            shrinkWrap: true,
            padding: EdgeInsets.symmetric(
              horizontal: 20,
            ),
            itemCount: controller.orders.length,
            physics: BouncingScrollPhysics(),
            itemBuilder: (context, index) {
              final order = controller.orders[index];
              return OrdersscreenCard(order: order,);
            },
          )),
        ],
      )),
    );
  }
}
