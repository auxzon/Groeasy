import 'package:auxzonfoodapp/controller/CategoryController/CategoryscreenController.dart';
import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../Category_Details/categorydetailscreen.dart';

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final searchController = TextEditingController();
    var controller = Get.put(CategoryScreenController());

    return BaseScreen(
      bgcolor: const Color(0xFFFFFFFF),
      appBar: AppBar(
        forceMaterialTransparency: true,
        automaticallyImplyLeading: false,
        title: TextwithFont(
            text: 'Categories', size: 20, fontweight: FontWeight.bold),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      child: SafeArea(
        child: Column(
          children: [
            // Search Bar
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  hintText: 'Search categories...',
                  prefixIcon: const Icon(Icons.search, color: Colors.black54),
                  filled: true,
                  fillColor: Color(0xFFFFFFFF),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: Color(0xFFA8A8A8),
                      width: 1
                    ),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16,vertical: 10),
                children: [
                  // Hot Deals Section
                  const SectionHeader(title: 'Hot Deals'),
                  HorizontalListView(
                    items: controller.hotDeals.map((deal) {
                      return GestureDetector(
                        onTap: () {
                          Navi.to(CategoryDetailsScreen(
                            categoryName: deal['title']!,
                            products: controller.getProductsForCategory("Fruits"), // Fetch products
                          ));
                        },
                        child: CategoryCard(
                          title: deal['title']!,
                          imageUrl: deal['imageUrl']!,
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),

                  // Categories by Store Section
                  const SectionHeader(title: 'Categories by Store'),
                  HorizontalListView(
                    items: controller.categoriesByStore.map((store) {
                      return GestureDetector(
                        onTap: () {
                          Navi.to(CategoryDetailsScreen(
                            categoryName: store['title']!,
                            products: controller.getProductsForCategory("Fruits"), // Fetch products
                          ));
                        },
                        child: CategoryCard(
                          title: store['title']!,
                          imageUrl: store['imageUrl']!,
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),

                  // General Categories Section
                  const SectionHeader(title: 'Other Categories'),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                    SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: MyApp.width*.02,
                      mainAxisSpacing: MyApp.height*.02,
                      childAspectRatio: (MyApp.height*.2) / (MyApp.width*.3),
                    ),
                    itemCount: controller.otherCategories.length,
                    itemBuilder: (context, index) {
                      var category = controller.otherCategories[index];
                      return GestureDetector(
                        onTap: () {
                          Navi.to(CategoryDetailsScreen(
                            categoryName: category['title']!,
                            products: controller.getProductsForCategory("Fruits"), // Fetch products
                          ));
                        },
                        child: CategoryCard(
                          title: category['title']!,
                          imageUrl: category['imageUrl']!,
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            SizedBox(height: MyApp.height*.02,)
          ],
        ),
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;

  const SectionHeader({required this.title, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: TextwithFont(
        text: title,
          size: 18,
          fontweight: FontWeight.bold,
        ),
    );
  }
}

class HorizontalListView extends StatelessWidget {
  final List<Widget> items;

  const HorizontalListView({required this.items, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MyApp.height*.22,
      child: ListView.separated(
        padding: EdgeInsets.symmetric(vertical: MyApp.height*.02),
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        itemBuilder: (context, index) => items[index],
        separatorBuilder: (context, index) => const SizedBox(width: 16),
      ),
    );
  }
}

class CategoryCard extends StatelessWidget {
  final String title;
  final String imageUrl;

  const CategoryCard({required this.title, required this.imageUrl, Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MyApp.width*.4,
      height: MyApp.height*.22,
      // decoration: BoxDecoration(
      //   color: Colors.white,
      //   borderRadius: BorderRadius.circular(12),
      //   boxShadow: [
      //     BoxShadow(
      //       color: Colors.black.withOpacity(0.1),
      //       blurRadius: 6,
      //       offset: const Offset(0, 4),
      //     ),
      //   ],
      // ),
      child: Column(
        crossAxisAlignment:CrossAxisAlignment.start ,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(5)),
            child: CachedNetworkImage(
              imageUrl: imageUrl,
              width: double.infinity,
              height: MyApp.height * 0.12,
              fit: BoxFit.cover,
              placeholder: (context, url) => Center(
                child: CircularProgressIndicator(),
              ),
              errorWidget: (context, url, error) => Container(
                color: Colors.grey[300],
                child: const Icon(
                  Icons.broken_image,
                  size: 50,
                  color: Colors.grey,
                ),
              ),
            ),
          ),
          // ClipRRect(
          //   borderRadius: const BorderRadius.vertical(top: Radius.circular(5)),
          //   child:
          //   Image.network(
          //     imageUrl,
          //     width: double.infinity,
          //     height: MyApp.height*.12,
          //     fit: BoxFit.cover,
          //     loadingBuilder: (BuildContext context, Widget child,
          //         ImageChunkEvent? loadingProgress) {
          //       if (loadingProgress == null) return child;
          //       return Center(
          //         child: CircularProgressIndicator(
          //           value: loadingProgress.expectedTotalBytes != null
          //               ? loadingProgress.cumulativeBytesLoaded /
          //               (loadingProgress.expectedTotalBytes ?? 1)
          //               : null,
          //         ),
          //       );
          //     },
          //     errorBuilder: (context, error, stackTrace) => Container(
          //       color: Colors.grey[300],
          //       child: const Icon(
          //         Icons.broken_image,
          //         size: 50,
          //         color: Colors.grey,
          //       ),
          //     ),
          //   ),
          // ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextwithFont(
              overfloww: TextOverflow.ellipsis,
             maxln: 1,
             text: title,
              align: TextAlign.center,
                size: 16,
                fontweight: FontWeight.bold,
              ),
            )
        ],
      ),
    );
  }
}
