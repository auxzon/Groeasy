import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../controller/AccountController/AccountController.dart';

class EditProfileBottomSheet extends StatelessWidget {
  final ProfileController profileController;

  EditProfileBottomSheet({required this.profileController});

  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    _nameController.text = profileController.name.value;
    _emailController.text = profileController.email.value;
    _addressController.text = profileController.address.value;

    return Container(
      padding: EdgeInsets.all(16),
      child: Wrap(
        children: [
          Align(
            alignment: Alignment(0, 0),
            child: Text("Edit Profile",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ),
          TextField(
            controller: _nameController,
            decoration: InputDecoration(labelText: "Name"),
          ),
          TextField(
            controller: _emailController,
            decoration: InputDecoration(labelText: "Email"),
          ),
          TextField(
            controller: _addressController,
            decoration: InputDecoration(labelText: "Address"),
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              profileController.updateProfile(
                _nameController.text,
                _emailController.text,
                _addressController.text,
                'images/new_profile_image.png', // Replace with image picker path
              );
              Get.back(); // Close the bottom sheet
            },
            child: TextwithFont(
              text: "Save",
              fontweight: FontWeight.bold,
              color: Theme.of(context).colorScheme.inversePrimary,
            ),
          ),
        ],
      ),
    );
  }
}
