import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class OrdersscreenCard extends StatelessWidget {
  final Map<String, dynamic> order;

  const OrdersscreenCard({required this.order});

  @override
  Widget build(BuildContext context) {
    double totalAmount = order["items"]
        .map(
            (item) => double.parse(item["price"]) * int.parse(item["quantity"]))
        .reduce((value, element) => value + element);

    return Card(
      color: Theme.of(context).colorScheme.inversePrimary,
      elevation: 20,
      margin: EdgeInsets.all(10.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextwithFont(
              text: "Order #${order['orderNumber']}",
              fontweight: FontWeight.bold,
              color: Theme.of(context).colorScheme.onSurface,
            ),
            TextwithFont(
              text: order['orderDate'],
              fontweight: FontWeight.normal,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(.8),
            ),
            SizedBox(height: 10),
            Column(
              children: List.generate(order["items"].length, (itemIndex) {
                final item = order["items"][itemIndex];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.asset(
                          item["image"],
                          width: 60,
                          height: 60,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextwithFont(
                              text: item["foodName"],
                              fontweight: FontWeight.bold,
                              color: Theme.of(context).colorScheme.onSurface,
                            ),
                            TextwithFont(
                              text: item["description"],
                              fontweight: FontWeight.normal,
                              color: Theme.of(context).colorScheme.onSurface.withOpacity(.8),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          TextwithFont(
                            text: "\$${item['price']}",
                            fontweight: FontWeight.bold,
                            color: Theme.of(context).colorScheme.onSurface,
                          ),
                          TextwithFont(
                            text: "Qty: ${item['quantity']}",
                            fontweight: FontWeight.normal,
                            color: Theme.of(context).colorScheme.onSurface.withOpacity(.8),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              }),
            ),
            Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextwithFont(
                  text: "${order['items'].length} Items",
                  fontweight: FontWeight.normal,
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(.8),
                ),
                TextwithFont(
                  text: "\$${totalAmount.toStringAsFixed(2)}",
                  fontweight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ],
            ),
            SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}
