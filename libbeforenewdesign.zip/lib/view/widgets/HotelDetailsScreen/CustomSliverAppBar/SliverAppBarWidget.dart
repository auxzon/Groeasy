import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../utils/color.dart';
import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Sliverappbarwidget extends StatelessWidget {
  var name;
  var image;

  Sliverappbarwidget({super.key,required this.name,required this.image});

  @override
  Widget build(BuildContext context) {
    return  SliverAppBar(
      automaticallyImplyLeading: false,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios, color:  Theme.of(context).colorScheme.inversePrimary),
        onPressed: () =>
        // controllerb.navcontroller.jumpToTab(0)
        Get.back()
        ,
      ),
      elevation: 10,
      backgroundColor: Theme.of(context).colorScheme.primary.withAlpha(500),
      pinned: true,
      snap: false,
      floating: true,
      expandedHeight: 180.0,
      flexibleSpace: FlexibleSpaceBar(
        title: TextwithFont(
            text: name,
            size: 15,
            color: liteColor,
            fontweight: FontWeight.w700),
        background: Image.asset(
          image,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
