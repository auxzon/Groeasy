import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/src/rx_typedefs/rx_typedefs.dart';

import '../../../../controller/BootomSheetController/Controller/BottomNavgationBarController.dart';
import '../../../../controller/HomeController/HomeScreenController.dart';
import '../../../../main.dart';
import '../../../../utils/color.dart';
import '../../../Common/BottomSheet/BottomSheet.dart';
import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Paymentscreenappbar extends StatelessWidget {
  const Paymentscreenappbar({super.key,
    required this.title,
    this.hmarg,
    this.vmarg,
  required this.onTap});

  final String title;
  final double? hmarg;
  final double? vmarg;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin:
      EdgeInsets.symmetric(vertical: vmarg ?? 5, horizontal: hmarg ?? 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(25),
        color: Theme.of(context).colorScheme.primary,
      ),
      height: MyApp.height * .1,
      width: MyApp.width,
      child: Center(
        child: Row(
          children: [
            IconButton(
              icon: Icon(Icons.arrow_back_ios, color: liteColor),
              onPressed: onTap,
            ),
            TextwithFont(
                text: title,
                size: 25,
                color: liteColor,
                fontweight: FontWeight.bold),
          ],
        ),
      ),
    );
  }
}
