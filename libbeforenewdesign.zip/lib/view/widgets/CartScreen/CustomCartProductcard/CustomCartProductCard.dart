import 'package:auxzonfoodapp/controller/CartScreenController/CartScreenController.dart';
import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:auxzonfoodapp/view/Common/ProductDetailsPage/ProductDetailsPage1.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import '../../../../controller/ProductDetailsController/ProductDetailsController.dart';
import '../../../../main.dart';
import '../../../../utils/color.dart';
import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Customcartproductcard extends StatelessWidget {
  const Customcartproductcard(
      {super.key, required this.controller, required this.index});

  final CartScrennController controller;
  final int index;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          Get.delete<Productdetailscontroller>();
          Navi.to(Productdetailspage1(
              name: controller.Foodnamelist[index],
              image: controller.Foodimglist[index],
              rate: double.parse(controller.Foodratelist[index]),
              rating: controller.Foodratinglist[index]));
        },
        child: Card(
          color: Theme.of(context).colorScheme.inversePrimary,
          child: Padding(
            padding: const EdgeInsets.all(8.0), // Add some padding around the content
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.20,
                  height: MediaQuery.of(context).size.width * 0.20,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: AssetImage("${controller.Foodimglist[index]}"),
                    ),
                  ),
                ),
                SizedBox(width: 12.0),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextwithFont(
                        text: controller.Foodnamelist[index],
                        fontweight: FontWeight.bold,
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                      TextwithFont(
                        text: "Rs .${controller.Foodratelist[index]}",
                        fontweight: FontWeight.w100,
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(.8),
                      ),
                      // Trailing Icons Column
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: Icon(Icons.add_circle_outline_outlined),
                            color: Theme.of(context).colorScheme.primary,
                          ),
                          TextwithFont(text: "${controller.FoodQtylist[index]}", fontweight: FontWeight.w900),
                          IconButton(
                            onPressed: () {},
                            icon: Icon(Icons.remove_circle_outline),
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),


              ],
            ),
          ),
        )
        );
  }
}
