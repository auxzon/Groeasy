// import 'package:auxzonfoodapp/controller/CartScreenController/CartScreenController.dart';
// import 'package:auxzonfoodapp/view/PaymentPage/PaymentScreen.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// import '../../../../main.dart';
// import '../../../../utils/color.dart';
// import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
//
// class Buybuttonwidget extends StatelessWidget {
//   const Buybuttonwidget({super.key,required this.controller,required this.rate});
// final CartScrennController controller;
// final int rate;
//   @override
//   Widget build(BuildContext context) {
//     return Obx(() => FilledButton.tonalIcon(
//       onPressed: () {
//         controller.atBottom.value? Get.to(()=>PaymentScreen(rate: rate)):null;
//       },
//       style: ButtonStyle(
//           iconColor: WidgetStatePropertyAll(liteColor),
//           backgroundColor: WidgetStatePropertyAll(
//             Theme.of(context).colorScheme.primary,
//           )),
//       label: TextwithFont(
//         text: controller.atBottom.value
//             ? "Buy Now"
//             : "Total amount : ${rate}/-",
//         size: 20.00,
//         color: liteColor,
//         fontweight: FontWeight.bold,
//       ),
//       icon: controller.atBottom.value
//           ? const Icon(Icons.shopping_bag_outlined)
//           : const Icon(Icons.add_card),
//     ),);
//   }
// }
