// import 'package:flutter/material.dart';
//
// import '../../../../main.dart';
// import '../../../../utils/color.dart';
// import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
//
// class Cartscreenappbar extends StatelessWidget {
//   const Cartscreenappbar({super.key, required this.title});
//
//   final String title;
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: EdgeInsets.symmetric(vertical: 5, horizontal: 20),
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(25),
//       ),
//       height: MyApp.height * .1,
//       width: MyApp.width,
//       child: Center(
//         child: TextwithFont(
//             text: "${title}",
//             size: 25,
//             color: Theme.of(context).colorScheme.primary,
//             fontweight: FontWeight.bold),
//       ),
//     );
//   }
// }
