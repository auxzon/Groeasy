import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:flutter/material.dart';
import 'package:auxzonfoodapp/view/HotelDetailsScreen/HotelDetailsScreen.dart';
import 'package:get/get.dart';

import '../../../../controller/HomeController/HomeScreenController.dart';
import '../../../../utils/TextFont.dart';
import '../../../../utils/color.dart';

class Hotelproductscard extends StatelessWidget {
  Hotelproductscard({super.key, required this.controller, required this.index});

  final Homescreencontroller controller;
  var index;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
       Navi.to(Hoteldetailsscreen(
         hmController: controller,
         image: controller.Hotelimglist[index],
         name: controller.Hotelnamelist[index],
       ));
      },
      child:  Material(
        color: Theme.of(context).colorScheme.inversePrimary,
        elevation: 15,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              )),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                child: Image.asset(controller.Hotelimglist[index]),
              ),
              Expanded(
                child: Text(
                  controller.Hotelnamelist[index],
                  style: Font1.bodyLarge?.copyWith(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
