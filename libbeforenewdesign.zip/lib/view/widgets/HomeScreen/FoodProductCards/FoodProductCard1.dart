import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../controller/HomeController/HomeScreenController.dart';
import '../../../../controller/ProductDetailsController/ProductDetailsController.dart';
import '../../../../main.dart';
import '../../../../utils/TextFont.dart';
import '../../../../utils/color.dart';
import '../../../Common/ProductDetailsPage/ProductDetailsPage1.dart';

class FoodProductCard1 extends StatelessWidget {
  FoodProductCard1({super.key, required this.controller, required this.index});

  Homescreencontroller controller;
  var index;

  @override
  Widget build(BuildContext context) {
    return InkResponse(
      onTap: () {
        Get.delete<Productdetailscontroller>();
        // Get.to(()=>,preventDuplicates: false);
        Navi.to(Productdetailspage1(
          name: controller.Foodnamelist[index],
          image: controller.Foodimglist[index],
          rate: double.parse(controller.Foodratelist[index]),
          rating: controller.Foodratinglist[index],
        ),preventdub: false);
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Material(
              borderRadius: BorderRadius.circular(15),
              elevation: 10,
              child: Container(
                height: MyApp.height * .14,
                width: MyApp.height * .14,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: AssetImage("${controller.Foodimglist[index]}"),
                  ),
                ),
              ),
            ),
            Flexible(
              child: TextwithFont(
                text: "${controller.Foodnamelist[index]}",
                  size: 16,
                  fontweight: FontWeight.w500,
                  color: Theme.of(context).colorScheme.primary.withOpacity(.8),
                maxln: 1,
                overfloww: TextOverflow.ellipsis,
                align: TextAlign.left,
              ),
            ),
            Flexible(
              child: TextwithFont(
                text: "Rs.${controller.Foodratelist[index]}",
                size: 14,
                fontweight: FontWeight.bold,
                color: bottombarselectedcolor,
                maxln:1,
                overfloww: TextOverflow.ellipsis,
                align: TextAlign.left,
              ),
            ),
            Flexible(
              child: Row(
                children: [
                  Icon(
                    Icons.star,
                    color: ratingcolor,
                    size: 14,
                  ),
                  SizedBox(width: 4),
                  TextwithFont(
                    text: "${controller.Foodratinglist[index]}",
                    size: 10,
                    fontweight: FontWeight.bold,
                    color: bottombarselectedcolor,
                    maxln: 3,
                    overfloww: TextOverflow.ellipsis,
                    align: TextAlign.left,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
