import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../../../../utils/color.dart';
import '../../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Otherdetails extends StatelessWidget {
  const Otherdetails({super.key,
    required this.time,
    required this.loc,
    required this.hotel,
    required this.price,
  });
  final int time;
  final String loc;
  final String hotel;
  final double price;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              Icon(CupertinoIcons.clock),
              TextwithFont(
                  text: "${time} min remaining",
                  size: 15,
                  color: Theme.of(context).colorScheme.surface,
                  fontweight: FontWeight.w700),
            ],
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Card(
            elevation: 10,
            margin: EdgeInsets.symmetric(vertical: 10),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextwithFont(
                      text: hotel,
                      size: 15,
                      color: Theme.of(context).colorScheme.onPrimary,
                      fontweight: FontWeight.bold),
                  TextwithFont(
                      text: loc,
                      size: 15,
                      color: Theme.of(context).colorScheme.secondary,
                      fontweight: FontWeight.bold),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: TextwithFont(
              text: "Rs. ${price}",
              size: 25,
              color: Theme.of(context).colorScheme.primary,
              fontweight: FontWeight.bold),
        ),
      ],
    );
  }
}
