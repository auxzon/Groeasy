import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

import '../../../../utils/color.dart';
import '../../../Common/ResultScreen/resultScreen.dart';
import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Addtocartbuttonwidget extends StatelessWidget {
  const Addtocartbuttonwidget({super.key});

  @override
  Widget build(BuildContext context) {
    return FilledButton.tonalIcon(
      onPressed: () {
       Navi.to(Resultscreen(
           Widgets: Center(
             child: Column(
               mainAxisSize: MainAxisSize.min,
               children: [
                 Lottie.asset("images/cartadd.json"),
                 TextwithFont(
                     text: "Item Added To Cart",
                     size: 35,
                     color: Theme.of(context).colorScheme.primary,
                     fontweight: FontWeight.w700),
               ],
             ),
           )));
      },
      style: ButtonStyle(
          iconColor: WidgetStatePropertyAll(liteColor),
          backgroundColor: WidgetStatePropertyAll(
            Theme.of(context).colorScheme.primary,
          )),
      label: TextwithFont(
        text: "Add to Cart",
        size: 20.00,
        color: liteColor,
        fontweight: FontWeight.bold,
      ),
      icon: const Icon(Icons.add_shopping_cart),
    );
  }
}
