import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../utils/TextFont.dart';
import '../../../../utils/color.dart';

class Productdetailscount extends StatelessWidget {
  Productdetailscount(
      {super.key,
      required this.controller,
      required this.name,
      required this.rate,
      required this.rating});

  var controller;
  final String name;
  final double rate;
  final String rating;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            IconButton(
              onPressed: () => controller.decreaseCount(),
              icon: Icon(Icons.remove),
              color: Theme.of(context).colorScheme.primary,
            ),
            Obx(() => Text(
                  "${controller.productCount}",
                  style: Font1.bodyLarge?.copyWith(
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                )),
            IconButton(
              onPressed: () => controller.increaseCount(),
              icon: Icon(Icons.add),
              color: Theme.of(context).colorScheme.primary,
            ),
          ],
        ),
        SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              name,
              style: Font1.bodyLarge?.copyWith(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.star,
                  color: ratingcolor,
                  size: 25,
                ),
                SizedBox(width: 4),
                Text(
                  "${rating}",
                  style: Font1.bodyLarge?.copyWith(
                    fontSize: 20,
                    fontWeight: FontWeight.w500,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ],
            ),
          ],
        ),
        Obx(
          () => Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Rs.${rate * controller.productCount.value}",
              style: Font1.bodyLarge?.copyWith(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
