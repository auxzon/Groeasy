// import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
// import 'package:flutter/material.dart';
// import '../../../../utils/color.dart';
//
// class Hotelcard extends StatelessWidget {
//   const Hotelcard(
//       {super.key,
//       required this.hotelname,
//       required this.hotelloc,
//       required this.km});
//   final String hotelname;
//   final String hotelloc;
//   final String km;
//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       elevation: 15,
//       child: ListTile(
//         title: TextwithFont(text: hotelname, fontweight: FontWeight.bold,color: liteColor,),
//         subtitle: TextwithFont(text: hotelloc, fontweight: FontWeight.w700,color: liteColor,),
//         trailing: TextwithFont(text: km, fontweight: FontWeight.w700,color: liteColor,),
//       ),
//       color: Theme.of(context).colorScheme.secondary,
//     );
//   }
// }
