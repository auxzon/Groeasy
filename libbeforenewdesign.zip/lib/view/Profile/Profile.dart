import 'package:auxzonfoodapp/controller/ThemeController/ThemeControllers.dart';
import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/Common/CommonAppbar/CommonAppbar.dart';
import 'package:auxzonfoodapp/view/Common/Navigation/navigation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import '../../controller/AccountController/AccountController.dart';
import '../../controller/AuthController/AuthController.dart';
import '../../controller/BootomSheetController/Controller/BottomNavgationBarController.dart';
import '../../controller/SplashScreenController/SplashScreenController.dart';
import '../../utils/ScafoldWithsafearea.dart';
import '../Orders/OrdersScreen.dart';
import '../SplashScreen/SplashScreen.dart';
import '../widgets/AccountScreen/BottomSheet/BottomSheet.dart';

class Myaccount extends StatelessWidget {
  const Myaccount({super.key});

  @override
  Widget build(BuildContext context) {
    final themeController = Get.put(ThemeControllers());
    var controller = Get.put(ProfileController());
    var authcontroller = Get.put(AuthController(context: context));
    void _showEditProfileBottomSheet(BuildContext context) {
      Get.bottomSheet(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        EditProfileBottomSheet(profileController: controller),
        isScrollControlled: true,
      );
    }
    return BaseScreen(
        child: Stack(
      children: [
        SizedBox(
          width: MyApp.width,
          height: MyApp.height,
        ),
        Container(
          width: MyApp.width,
          height: MyApp.height * .6,
          decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(35),
                  bottomRight: Radius.circular(35))),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CommonAppbar(
                  title: "My Profile",
                  rightonTap: () {
                    Get.delete<SplashScreenController>();
                    authcontroller.logout();
                    Get.delete<AuthController>();
                    Get.delete<BottomNavigationBarController>();
                    Get.offAll(() => SplashScrren());
                  },
                  rightmaterial: Icon(Icons.logout,color: liteColor,),
                ),
                Spacer(
                  flex: 1,
                ),
                Container(
                  padding: EdgeInsets.all(2), // Border thickness
                  decoration: BoxDecoration(
                    color: liteColor, // Border color
                    shape: BoxShape.circle,
                  ),
                  child: CircleAvatar(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    backgroundImage: AssetImage("images/hotel5.jpg"),
                    radius: 50, // Adjust the size as needed
                  ),
                ),
               Obx(() =>  Center(
                 child: TextwithFont(
                   textDecoration: TextDecoration.underline,
                   doccolors: liteColor,
                   text: controller.name.value,
                   size: 25,
                   color: liteColor,
                   fontweight: FontWeight.bold,
                 ),
               ),),
                Obx(() => Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextwithFont(
                        text: controller.email.value,
                        size: 15,
                        color: liteColor,
                        fontweight: FontWeight.bold,
                      ),
                      IconButton(
                          onPressed: () {
                            _showEditProfileBottomSheet(context);
                          },
                          icon: Icon(
                            Icons.edit_sharp,
                            color: liteColor,
                          ))
                    ],
                  ),
                ),),
                Spacer(
                  flex: 2,
                ),
                SizedBox(
                  height: MyApp.height * .06,
                )
              ],
            ),
          ),
        ),
        Positioned(
            bottom: 0,
            child: SizedBox(
              height: MyApp.height * .4,
              width: MyApp.width,
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  height: MyApp.height * .25,
                  width: MyApp.width * .8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextwithFont(
                          text: "© 2024 Food App. All rights reserved.",
                          fontweight: FontWeight.bold),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextwithFont(
                            size: 10,
                            align: TextAlign.center,
                            text:
                                "This application and its contents are protected under applicable copyright and intellectual property laws. Unauthorized use or reproduction is prohibited.",
                            fontweight: FontWeight.normal),
                      ),
                    ],
                  ),
                ),
              ),
            )),
        Positioned(
          top: MyApp.height * .3,
          bottom: 0,
          left: 0,
          right: 0,
          child: Center(
            child: Material(
              color: Theme.of(context).colorScheme.inversePrimary,
              elevation: 25,
              borderRadius: BorderRadius.circular(25),
              child: Container(
                height: MyApp.height * .35,
                width: MyApp.width * .8,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.inversePrimary,
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // TextwithFont(
                            //   text: "Select Your Theme",
                            //   size: 20,
                            //   color: Theme.of(context).colorScheme.primary,
                            //   fontweight: FontWeight.bold,
                            // ),
                            // Obx(
                            //   () => Switch(
                            //     autofocus: true,
                            //     activeTrackColor:
                            //         Theme.of(context).colorScheme.primary,
                            //     activeColor:
                            //         Theme.of(context).colorScheme.onPrimary,
                            //     inactiveThumbColor:
                            //         Theme.of(context).colorScheme.primary,
                            //     inactiveTrackColor: Theme.of(context)
                            //         .colorScheme
                            //         .inversePrimary,
                            //     value: themeController.isDarkMode.value,
                            //     onChanged: (value) {
                            //       themeController.toggleTheme();
                            //     },
                            //   ),
                            // ),
                            Padding(
                              padding: const EdgeInsets.all(15),
                              child: Row(
                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  GestureDetector(
                                    onTap:(){
                                      Navi.to(Ordersscreen());
                                    },
                                    child: TextwithFont(
                                      size: 15,
                                      text: "no of Orders",
                                      fontweight: FontWeight.bold,
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap:(){
                                      Navi.to(Ordersscreen());
                                    },
                                    child: TextwithFont(
                                        text: "20", fontweight: FontWeight.w100),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(15),
                              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [

                                  TextwithFont(
                                    size: 15,
                                    text: "points",
                                    fontweight: FontWeight.bold,
                                  ),
                                  TextwithFont(
                                      text: "20", fontweight: FontWeight.w100),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(15),
                              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [

                                  TextwithFont(
                                    size: 15,
                                    text: "total hours",
                                    fontweight: FontWeight.bold,
                                  ),
                                  TextwithFont(
                                      text: "10 hr", fontweight: FontWeight.w100),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(15),
                              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [

                                  TextwithFont(
                                    size: 15,
                                    text: "trips",
                                    fontweight: FontWeight.bold,
                                  ),
                                  TextwithFont(
                                      text: "8", fontweight: FontWeight.w100),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    )
        );
  }

}
