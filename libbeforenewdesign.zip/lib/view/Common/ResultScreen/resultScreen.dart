import 'package:auxzonfoodapp/utils/color.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../controller/ResultScreenController/ResultScreenController.dart';

class Resultscreen extends StatelessWidget {
  Resultscreen({super.key,required this.Widgets,this.index});
  Widget Widgets;
  int? index;
  @override
  Widget build(BuildContext context) {
    var controller = Get.put(ResultScreenConntroller());
    return Scaffold(
      backgroundColor: liteColor,
      body: Widgets,
    );
  }
}
