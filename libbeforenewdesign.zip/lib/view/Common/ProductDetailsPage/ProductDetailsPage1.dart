import 'package:auxzonfoodapp/view/widgets/ProductDetailsScreen/Addtocartbutton/AddtoCartButtonWidget.dart';
import 'package:flutter/material.dart';
import 'package:auxzonfoodapp/controller/ProductDetailsController/ProductDetailsController.dart';
import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/view/widgets/ProductDetailsScreen/HotelCard/HotelCard.dart';
import 'package:auxzonfoodapp/view/widgets/ProductDetailsScreen/ProductDetailsCount/ProductDetailsCount.dart';
import 'package:auxzonfoodapp/view/widgets/ProductDetailsScreen/ProductImages/ProductImage.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

import '../../../controller/BootomSheetController/Controller/BottomNavgationBarController.dart';
import '../../../controller/HomeController/HomeScreenController.dart';
import '../../../utils/color.dart';
import '../../widgets/HomeScreen/FoodProductCards/FoodProductCard1.dart';
import '../../widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import '../ResultScreen/resultScreen.dart';

class Productdetailspage1 extends StatelessWidget {
  const Productdetailspage1(
      {super.key,
      required this.name,
      required this.image,
      required this.rate,
      required this.rating});

  final String name;
  final String image;
  final double rate;
  final String rating;

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(Productdetailscontroller());
    var controllerh = Get.find<Homescreencontroller>();
    var controllerb = Get.find<BottomNavigationBarController>();

    return BaseScreen(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Addtocartbuttonwidget(),
      child: Stack(
        children: [
          ListView(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            shrinkWrap: true,
            physics: const BouncingScrollPhysics(),
            children: [
              Productimage(image: image),
              SizedBox(height: MyApp.height * .02),
              Center(
                child: TextwithFont(
                  text: "Details",
                  size: 24.00,
                  color: Theme.of(context).colorScheme.primary,
                  fontweight: FontWeight.bold,
                ),
              ),
              Productdetailscount(
                  controller: controller,
                  name: name,
                  rate: rate,
                  rating: rating),
              // SizedBox(height: 20),
              // Hotelcard(
              //     hotelname: "OLD HARBOUR HOTEL",
              //     hotelloc: "Vyttila, Kochi",
              //     km: "15km away"),
              SizedBox(height: 20),
              TextwithFont(
                  text: "Similar Products",
                  size: 20,
                  color: Theme.of(context).colorScheme.primary,
                  fontweight: FontWeight.bold),
              SizedBox(
                // color: Colors.redAccent,
                height: MyApp.height * .25,
                width: MyApp.width,
                child: ListView.builder(
                  physics: BouncingScrollPhysics(),
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  scrollDirection: Axis.horizontal,
                  itemCount: controllerh.Foodimglist.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return FoodProductCard1(
                        controller: controllerh, index: index);
                  },
                ),
              ),
              SizedBox(height: MyApp.height * .1),
            ],
          ),
          Positioned(
            top: 0.0,
            left: 0.0,
            right: 0.0,
            child: AppBar(
              forceMaterialTransparency: true,
              backgroundColor: Colors.transparent,
              title: const Text(''),
              // You can add title here
              leading: IconButton(
                icon: Icon(Icons.arrow_back_ios, color: Color(0xFF000000)),
                onPressed: () =>
                  // controllerb.navcontroller.jumpToTab(0)
                Get.back()
                ,
              ),
              elevation: 0.0, //No shadow
            ),
          ),
        ],
      ),
    );
  }
}
