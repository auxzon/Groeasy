import 'package:flutter/material.dart';
import 'package:get/get_rx/src/rx_typedefs/rx_typedefs.dart';
import '../../../utils/color.dart';
import '../../widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class CommonAppbar extends StatelessWidget {
  const CommonAppbar({
    super.key,
    required this.title,
    this.leftonTap,
    this.leftpading,
    this.rightpading,
    this.rightonTap,
    this.rightmaterial,
    this.titlecolor,
    this.leftcolor,
  });

  final String title;
  final Callback? leftonTap;
  final Callback? rightonTap;
  final Widget? rightmaterial;
  final Color? titlecolor;
  final Color? leftcolor;
  final double? leftpading;
  final double? rightpading;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if(leftonTap!=null)IconButton(
            icon: Icon(Icons.arrow_back_ios_new_sharp, color: leftcolor??liteColor),
            onPressed: leftonTap,
          ),
          if(leftonTap!=null)Spacer(),
          Padding(
            padding:  EdgeInsets.only(left: leftpading??25,right: rightpading??0),
            child: TextwithFont(
                text: title,
                size: 25,
                color: titlecolor??liteColor,
                fontweight: FontWeight.bold),
          ),
          Spacer(),
          MaterialButton(onPressed: rightonTap,child: rightmaterial)
        ],
      ),
    );
  }
}
