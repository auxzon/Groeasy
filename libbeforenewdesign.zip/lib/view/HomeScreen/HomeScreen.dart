import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:auxzonfoodapp/controller/HomeController/HomeScreenController.dart';
import 'package:auxzonfoodapp/main.dart';
import 'package:get/get.dart';

import '../../controller/WidgetControllers/HomeScreen/Searchbar/SearchBarController.dart';
import '../../utils/ScafoldWithsafearea.dart';
import '../widgets/HomeScreen/Appbar/AppBar.dart';
import '../widgets/HomeScreen/Banners/Banner1.dart';
import '../widgets/HomeScreen/FoodProductCards/FoodProductCard1.dart';
import '../widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import '../widgets/HomeScreen/HotelProductsCards/HotelProductsCard.dart';
import '../widgets/HomeScreen/SearchBar/view/SearchBarWidget.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(Homescreencontroller());
    var searchController = Get.put(SearchConroler(), tag: 'home');
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        SystemNavigator.pop();
      },
      child: BaseScreen(
        child: ListView(
          controller: controller.ListscrollController,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          children: [
            const CustomAppbar(
                image: "images/appicon2.png", name: "Kochi SuperMarket", count: 10),
            SearchBarAnimated(controller: searchController),
            const Banner1(),
            TextwithFont(
                text: "Hot Deals",
                size: 24.00,
                color: Theme.of(context).colorScheme.surface,
                fontweight: FontWeight.bold),
            SizedBox(
              // color: Colors.redAccent,
              height: MyApp.height * .25,
              width: MyApp.width,
              child: ListView.builder(
                physics: BouncingScrollPhysics(),
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                scrollDirection: Axis.horizontal,
                itemCount: controller.Foodimglist.length,
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return FoodProductCard1(controller: controller, index: index);
                },
              ),
            ),
            TextwithFont(
                text: "Best Categories",
                size: 24.00,
                color: Theme.of(context).colorScheme.surface,
                fontweight: FontWeight.bold),
            Container(
              margin: EdgeInsets.symmetric(vertical: 20),
              height: MyApp.height * .65,
              width: MyApp.width,
              // color: Colors.red,
              child: Obx(
                () => GridView.builder(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  controller: controller.scrollController,
                  physics: controller.atTop.value == false &&
                              controller.atBottom.value == true ||
                          controller.atTop.value == true &&
                              controller.atBottom.value == false
                      ? NeverScrollableScrollPhysics()
                      : BouncingScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: controller.Hotelimglist.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 1.1,
                  ),
                  itemBuilder: (context, index) {
                    return Hotelproductscard(
                        controller: controller, index: index);
                  },
                ),
              ),
            ),
            Banner1(),
          ],
        ),
      ),
    );
  }
}
