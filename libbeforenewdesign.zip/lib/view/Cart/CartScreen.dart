import 'package:auxzonfoodapp/controller/BootomSheetController/Controller/BottomNavgationBarController.dart';
import 'package:auxzonfoodapp/controller/CartScreenController/CartScreenController.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/Common/CommonAppbar/CommonAppbar.dart';
import 'package:auxzonfoodapp/view/widgets/CartScreen/CustomCartProductcard/CustomCartProductCard.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../PaymentPage/PaymentScreen.dart';

class Cartscreen extends StatelessWidget {
  const Cartscreen({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(CartScrennController());
    var btmcontroller = Get.find<BottomNavigationBarController>();
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        SystemNavigator.pop();
      },
      child: BaseScreen(
          child: ListView(
        children: [
          Obx(() => CommonAppbar(
            leftonTap: btmcontroller.hidebtmsheet.value==true?null:() {
              btmcontroller.navcontroller.jumpToTab(0);
              btmcontroller.hidebtmsheet.value = true;
            },
            leftcolor: Theme.of(context).colorScheme.primary,
            title: "Cart",
            rightonTap: () {},
            titlecolor: Theme.of(context).colorScheme.primary,
            rightmaterial:
            TextwithFont(text: "add more", fontweight: FontWeight.w600),
          ),),
          ListView.builder(
            shrinkWrap: true,
            padding: EdgeInsets.symmetric(
              horizontal: 20,
            ),
            itemCount: 5,
            physics: BouncingScrollPhysics(),
            itemBuilder: (context, index) =>
                Customcartproductcard(controller: controller, index: index),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextwithFont(
                      text: "items",
                      fontweight: FontWeight.w200,
                      color:
                          Theme.of(context).colorScheme.primary.withOpacity(.5),
                    ),
                    TextwithFont(
                      text: "3",
                      fontweight: FontWeight.w200,
                      color:
                          Theme.of(context).colorScheme.primary.withOpacity(.5),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextwithFont(
                      text: "Delivery Charge",
                      fontweight: FontWeight.w200,
                      color:
                          Theme.of(context).colorScheme.primary.withOpacity(.5),
                    ),
                    TextwithFont(
                      text: "Rs. 20",
                      fontweight: FontWeight.w200,
                      color:
                          Theme.of(context).colorScheme.primary.withOpacity(.5),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextwithFont(
                      text: "Sub Total",
                      fontweight: FontWeight.w200,
                      color:
                          Theme.of(context).colorScheme.primary.withOpacity(.5),
                    ),
                    TextwithFont(
                      text: "Rs. 200.00",
                      fontweight: FontWeight.w200,
                      color:
                          Theme.of(context).colorScheme.primary.withOpacity(.5),
                    ),
                  ],
                ),
                Divider(
                  color: Theme.of(context).colorScheme.primary.withOpacity(.5),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextwithFont(
                      text: "Total",
                      fontweight: FontWeight.bold,
                      size: 20,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    TextwithFont(
                      text: "Rs. 200.00",
                      fontweight: FontWeight.bold,
                      size: 20,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 25),
            child: MaterialButton(
              elevation: 5,
              onPressed: () {
                Get.bottomSheet(
                  elevation: 10,
                  isDismissible: true,
                  backgroundColor: Colors.grey.shade300,
                    PaymentScreen(rate: 200));
              },
              color: Theme.of(context).colorScheme.primary,
              child: TextwithFont(
                  text: "Proceed to CheckOut", fontweight: FontWeight.bold,color: liteColor),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
            ),
          )
        ],
      )),
    );
  }
}
