import 'package:auxzonfoodapp/controller/paymentController/PaymentController.dart';
import 'package:auxzonfoodapp/main.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key, required this.rate});

  final int rate;

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(PaymentController());

    return ListView(
      physics: const BouncingScrollPhysics(),
      children: [
        SizedBox(height: MyApp.height * .06),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25),
          child: TextwithFont(
            align: TextAlign.center,
            text: "Payment",
            textDecoration: TextDecoration.underline,
            doccolors: Theme.of(context).colorScheme.primary,
            size: 25,
            color: Theme.of(context).colorScheme.secondary,
            fontweight: FontWeight.bold,
          ),
        ),
        SizedBox(height: MyApp.height * .06),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Card(
            color: Theme.of(context).colorScheme.inversePrimary.withOpacity(.8),
            elevation: 20,
            child: Column(
            children: [
              SizedBox(height: MyApp.height * .01),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25),
                child: TextwithFont(
                  text: "Location",
                  size: 20,
                  color: Theme.of(context).colorScheme.secondary,
                  fontweight: FontWeight.w800,
                ),
              ),
              SizedBox(height: MyApp.height * .01),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25),
                child: Obx(() {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          controller.currentLocation.isNotEmpty
                              ? controller.currentLocation.value
                              : "Fetching location...",
                          style: TextStyle(
                              fontSize: 16,
                              color: Theme.of(context).colorScheme.secondary),
                        ),
                      ),
                      IconButton(
                          onPressed: () {
                            controller.fetchCurrentLocation();
                          },
                          icon: Icon(
                            Icons.refresh,
                            color: Theme.of(context).colorScheme.secondaryContainer,
                          ))
                    ],
                  );
                }),
              ),
              SizedBox(height: MyApp.height * .06),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25),
                child: Obx(() {
                  if (controller.result.isNotEmpty) {
                    return Row(
                      children: [
                        Text(
                          controller.result.value,
                          style: TextStyle(
                            fontSize: 16,
                            color: controller.status.value == 'SUCCESS'
                                ? Colors.green
                                : Colors.red,
                          ),
                        ),
                      ],
                    );
                  }
                  return Container();
                }),
              ),
              SizedBox(height: MyApp.height * .01),
            ],
          ),),
        ),
        SizedBox(height: MyApp.height * .02),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25),
          child: Obx(
            () => controller.currentLocation.isNotEmpty
                ? FilledButton.tonalIcon(
                    onPressed: () {
                      controller.startTransaction(context);
                    },
                    label: TextwithFont(
                      text: "Pay $rate",
                      size: 15,
                      color: Theme.of(context).colorScheme.onPrimary,
                      fontweight: FontWeight.w700,
                    ),
                    icon: Icon(Icons.payment,
                        color: Theme.of(context).colorScheme.onPrimary),
                  )
                : SizedBox.shrink(),
          ),
        ),
      ],
    );
  }

  // Separate showSnackBar method
  void _showSnackBar(BuildContext context, String message, Color color) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: color,
        ),
      );
    });
  }
}
