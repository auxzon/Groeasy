import 'package:auxzonfoodapp/controller/CartScreenController/CartScreenController.dart';
import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/widgets/CartScreen/BuyButton/BuyButtonWidget.dart';
import 'package:auxzonfoodapp/view/widgets/CartScreen/CustomCartProductcard/CustomCartProductCard.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class Cartscreen extends StatelessWidget {
  const Cartscreen({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(CartScrennController());
    return PopScope(
      canPop: false, onPopInvoked: (didPop) {
      SystemNavigator.pop();
    },
      child: BaseScreen(
          floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
          floatingActionButton: Buybuttonwidget(controller: controller,rate: 10,),
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: 5, horizontal: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  color: kColorScheme.primary,
                ),
                height: MyApp.height * .1,
                width: MyApp.width,
                child: Center(
                  child: TextwithFont(
                      text: "Cart",
                      size: 25,
                      color: liteColor,
                      fontweight: FontWeight.bold),
                ),
              ),
              Expanded(
                  child: ListView.builder(
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                ),
                controller: controller.ListscrollController,
                itemCount: controller.Foodratinglist.length,
                physics: BouncingScrollPhysics(),
                itemBuilder: (context, index) =>
                    Customcartproductcard(controller: controller, index: index),
              )),
            ],
          )),
    );
  }
}
