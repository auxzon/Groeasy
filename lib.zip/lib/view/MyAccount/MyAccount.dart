import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:auxzonfoodapp/view/widgets/MyAccountsAppbar/MyAccounntAppBar.dart';
import '../../controller/AccountController/AccountController.dart';
import '../../controller/BootomSheetController/Controller/BottomNavgationBarController.dart';
import '../../controller/HomeController/HomeScreenController.dart';
import '../../controller/ThemeCOntroller/ThemeController.dart';
import '../../utils/ScafoldWithsafearea.dart';
import '../Common/BottomSheet/BottomSheet.dart';
import '../widgets/AccountScreen/BottomSheet/BottomSheet.dart';

class Myaccount extends StatelessWidget {
  const Myaccount({super.key});

  @override
  Widget build(BuildContext context) {
    final themeController = Get.put(ThemeController());
    var controller = Get.put(AddressController());

    return BaseScreen(
      child: ListView(
        padding: EdgeInsets.symmetric(horizontal: 20),
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        children: [
          Myaccounntappbar(
            title: "My Profile",
            onTap: () {
              Get.delete<BottomNavigationBarController>();
              Get.delete<Homescreencontroller>();
              Get.delete<ThemeController>();
              Get.to(
                      () => BottomNavigator(
                    index: 2,
                  ),
                  transition: Transition.leftToRight);
            },
          ),
          Container(
            width: MyApp.width * .12,
            height: MyApp.height * .12,
            decoration: BoxDecoration(
              border: Border.all(color: kColorScheme.primary, width: 2),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person),
          ),
          Center(
            child: TextwithFont(
              textDecoration: TextDecoration.underline,
              colors: kColorScheme.primary,
              text: "Username",
              size: 25,
              color: kColorScheme.onPrimaryContainer,
              fontweight: FontWeight.bold,
            ),
          ),
          Center(
            child: TextwithFont(
              text: "username@gmail.com",
              size: 15,
              color: kColorScheme.primary,
              fontweight: FontWeight.bold,
            ),
          ),
          TextwithFont(
            text: "Details",
            size: 15,
            color: kColorScheme.primary,
            fontweight: FontWeight.bold,
          ),
          Card(
            elevation: 20,
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            color: Theme.of(context).cardColor, // Automatically adjusts based on theme
            child: Center(
              child: Column(
                children: [
                  ListTile(
                    leading: Icon(
                      Icons.production_quantity_limits,
                      color: Theme.of(context).iconTheme.color, // Icon color based on theme
                    ),
                    title: TextwithFont(
                      text: "Numbers of Orders",
                      size: 15,
                      color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.black, // Fallback to black if null
                      fontweight: FontWeight.w600,
                    ),
                    subtitle: TextwithFont(
                      text: "20",
                      size: 15,
                      color: Theme.of(context).textTheme.bodyMedium!.color?? Colors.black, // Adjust text color
                      fontweight: FontWeight.bold,
                    ),
                  ),
                  ListTile(
                    leading: Icon(
                      Icons.control_point_duplicate,
                      color: Theme.of(context).iconTheme.color, // Icon color based on theme
                    ),
                    title: TextwithFont(
                      text: "Points",
                      size: 15,
                      color: Theme.of(context).textTheme.bodyLarge!.color?? Colors.red, // Adjust text color
                      fontweight: FontWeight.w600,
                    ),
                    subtitle: TextwithFont(
                      text: "205",
                      size: 15,
                      color: Theme.of(context).textTheme.bodyMedium?.color?? Colors.black, // Adjust text color
                      fontweight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          ///
          // Card(
          //   elevation: 20,
          //   margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          //   child: Center(
          //     child: Column(
          //       children: [
          //         ListTile(
          //           leading: Icon(Icons.production_quantity_limits),
          //           title: TextwithFont(
          //             text: "Numbers of Orders",
          //             size: 15,
          //             color: kColorScheme.onSecondaryContainer,
          //             fontweight: FontWeight.w600,
          //           ),
          //           subtitle: TextwithFont(
          //             text: "20",
          //             size: 15,
          //             color: kColorSchemedark.onPrimaryContainer,
          //             fontweight: FontWeight.bold,
          //           ),
          //         ),
          //         ListTile(
          //           leading: Icon(Icons.control_point_duplicate),
          //           title: TextwithFont(
          //             text: "Points",
          //             size: 15,
          //             color: kColorScheme.onSecondaryContainer,
          //             fontweight: FontWeight.w600,
          //           ),
          //           subtitle: TextwithFont(
          //             text: "205",
          //             size: 15,
          //             color: kColorSchemedark.onPrimaryContainer,
          //             fontweight: FontWeight.bold,
          //           ),
          //         ),
          //       ],
          //     ),
          //   ),
          // ),
          ///
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Address",
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
      IconButton(
        onPressed: () {
          // Show AlertDialog for editing address
          showDialog(
            context: context,
            builder: (context) {
              return EditAddressDialog(); // Show the EditAddressDialog
            },
          );
        },
        icon: Icon(Icons.edit_note, color: Theme.of(context).iconTheme.color),
      ),
            ],
          ),

          // Card showing the address
          Obx(() => Card(
            elevation: 20,
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            color: Theme.of(context).cardColor,
            child: Center(
              child: ListTile(
                leading: Icon(
                  Icons.broadcast_on_personal_rounded,
                  color: Theme.of(context).iconTheme.color,
                ),

                subtitle: Text(
                  "${controller.address.value}",
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: Theme.of(context).textTheme.bodyMedium?.color,
                  ),
                ),
              ),
            ),
          )),
          TextwithFont(
            text: "Theme",
            size: 15,
            color: kColorScheme.primary,
            fontweight: FontWeight.bold,
          ),
          Card(
            elevation: 20,
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextwithFont(
                    text: "Dark Mode",
                    size: 15,
                    color: kColorScheme.primary,
                    fontweight: FontWeight.bold,
                  ),
                  Obx(() => Switch(
                    value: themeController.isDarkMode.value,
                    onChanged: (value) {
                      themeController.toggleTheme();
                    },
                  ),),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
