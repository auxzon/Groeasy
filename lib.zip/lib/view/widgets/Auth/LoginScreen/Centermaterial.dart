import 'dart:ui';

import 'package:auxzonfoodapp/controller/AuthController/AuthController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../main.dart';
import '../../../../utils/color.dart';
import '../../../Auth/Registration.dart';
import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Centermaterial extends StatelessWidget {
  const Centermaterial(
      {super.key,
      required this.materialheight,
      required this.materialwidth,
      required this.authController,
      required this.materialelevation});

  final AuthController authController;
  final double? materialelevation;
  final double? materialheight;
  final double? materialwidth;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: materialelevation??0,
      borderRadius: BorderRadius.circular(35),
      color: Colors.transparent,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(35),
        child: Container(
          height: materialheight,
          width: materialwidth,
          color: kColorScheme.surface.withOpacity(0.3),
          child: Stack(
            children: [
              BackdropFilter(
                filter: ImageFilter.blur(
                  sigmaX: 4,
                  sigmaY: 4,
                ),
                child: Container(),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Welcome Text
                    TextwithFont(
                      text: "Welcome to",
                      size: 28,
                      color: kColorScheme.surface,
                      fontweight: FontWeight.bold,
                    ),
                    TextwithFont(
                      text: "Food App",
                      size: 40,
                      color: kColorScheme.surface,
                      fontweight: FontWeight.bold,
                    ),
                    SizedBox(height: MyApp.height * .07),
                    TextField(
                      controller: authController.emailController,
                      decoration: InputDecoration(
                        hintText: 'Email',
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(15),
                          borderSide:
                              BorderSide(color: kColorScheme.onPrimaryFixed),
                        ),
                        prefixIcon: Icon(
                          Icons.mail,
                          color: kColorScheme.primary,
                        ),
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.8),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                    ),
                    SizedBox(height: MyApp.height * .02),
                    Obx(
                      () => TextField(
                        controller: authController.passwordController,
                        obscureText: !authController.showpasslg.value,
                        decoration: InputDecoration(
                          suffixIcon: IconButton(
                            onPressed: () {
                              authController.logtogglepass();
                            },
                            icon: Icon(authController.showpasslg.value
                                ? Icons.visibility
                                : Icons.visibility_off),
                          ),
                          hintText: 'Password',
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide:
                                BorderSide(color: kColorScheme.onPrimaryFixed),
                          ),
                          prefixIcon: Icon(
                            Icons.lock,
                            color: kColorScheme.primary,
                          ),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.8),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: MyApp.height * .02),

                    // Submit Button
                    Obx(
                      () => authController.isLoading.value
                          ? CircularProgressIndicator()
                          : MaterialButton(
                              elevation: 8,
                              minWidth: MediaQuery.of(context).size.width * 0.8,
                              height: 50,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                              color: kColorScheme.primary,
                              onPressed: authController.login,
                              child: Text(
                                "Login",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                    ),
                    SizedBox(height: MyApp.height * .04),

                    // Create Account Button
                    TextButton(
                      onPressed: () {
                        Get.to(() => RegisterScreen());
                      },
                      child: Text(
                        "Create new account?",
                        style: TextStyle(color: kColorScheme.onSurface),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
