import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../controller/HomeController/HomeScreenController.dart';
import '../../../../controller/ProductDetailsController/ProductDetailsController.dart';
import '../../../../main.dart';
import '../../../../utils/color.dart';
import '../../../Common/ProductDetailsPage/ProductDetailsPage1.dart';
import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Productcardinhoteldetailspage extends StatelessWidget {
   Productcardinhoteldetailspage({
    super.key,
    required this.hmController,
    required this.index,
  });
int index;
  final Homescreencontroller hmController;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Get.delete<Productdetailscontroller>();
        Get.to(() => Productdetailspage1(
            name: hmController.Foodnamelist[index],
            image: hmController.Foodimglist[index],
            rate: double.parse(hmController.Foodratelist[index]),
            rating: hmController.Foodratinglist[index]));
      },
      child: Card(
        child: ListTile(
          leading: Container(
            width: MyApp.width * .3,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                image: DecorationImage(
                    fit: BoxFit.cover,
                    image: AssetImage(hmController.Foodimglist[index]))),
          ),
          subtitle: TextwithFont(
              text: "Rs. ${hmController.Foodratelist[index]}",
              size: 10,
              color: kColorSchemedark.onPrimaryFixed,
              fontweight: FontWeight.bold),
          title: TextwithFont(
              text: hmController.Foodnamelist[index],
              size: 15,
              color: kColorSchemedark.primary,
              fontweight: FontWeight.w400),
          trailing: hmController.Foodtypelist[index] == "veg"
              ? Icon(
                  CupertinoIcons.dot_square,
                  color: vegfoodcolor,
                )
              : Icon(
                  CupertinoIcons.dot_square,
                  color: nonvegfoodcolor,
                ),
        ),
      ),
    );
  }
}
