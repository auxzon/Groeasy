import 'package:auxzonfoodapp/controller/CartScreenController/CartScreenController.dart';
import 'package:auxzonfoodapp/view/Common/ProductDetailsPage/ProductDetailsPage1.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import '../../../../controller/ProductDetailsController/ProductDetailsController.dart';
import '../../../../main.dart';
import '../../../../utils/color.dart';
import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Customcartproductcard extends StatelessWidget {
  const Customcartproductcard(
      {super.key, required this.controller, required this.index});

  final CartScrennController controller;
  final int index;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Get.delete<Productdetailscontroller>();
        Get.to(() => Productdetailspage1(
            name: controller.Foodnamelist[index],
            image: controller.Foodimglist[index],
            rate: double.parse(controller.Foodratelist[index]),
            rating: controller.Foodratinglist[index]));
      },
      child: Dismissible(
        key: Key(controller.Foodnamelist[index]),
        direction: DismissDirection.endToStart,
        onDismissed: (direction) {
          controller.Foodnamelist.removeAt(index);
          controller.FoodQtylist.removeAt(index);
          controller.Foodtypelist.removeAt(index);
          controller.Foodimglist.removeAt(index);
          controller.Hotelnamelist.removeAt(index);
          controller.Foodratelist.removeAt(index);
          controller.Foodratinglist.removeAt(index);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Item removed from cart')),
          );
        },
        background: Container(
          color: kColorSchemedark.onPrimaryContainer,
          alignment: Alignment.centerRight,
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Icon(
            Icons.delete,
            color: Colors.white,
          ),
        ),
        child: Card(
          elevation: 20,
          child: Container(
            padding: EdgeInsets.all(10),
            height: MyApp.height * .2,
            child: Row(
              children: [
                Expanded(
                    flex: 3,
                    child: Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage(controller.Foodimglist[index]),
                            fit: BoxFit.cover),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      margin: EdgeInsets.only(right: 10),
                    )),
                Expanded(
                  flex: 2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        child: TextwithFont(
                            text: controller.Hotelnamelist[index],
                            size: 15,
                            color: kColorScheme.primary,
                            fontweight: FontWeight.w100),
                      ),
                      Flexible(
                        child: TextwithFont(
                            text: controller.Foodnamelist[index],
                            size: 15,
                            color: kColorScheme.primary,
                            fontweight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
                Spacer(),
                Expanded(
                  flex: 2,
                  child: Column(
                    children: [
                      TextwithFont(
                          text: "Rs.${controller.Foodratelist[index]}",
                          size: 15,
                          color: kColorScheme.primary,
                          fontweight: FontWeight.w100),
                      Row(
                        children: [
                          Icon(
                            Icons.star,
                            color: ratingcolor,
                            size: 14,
                          ),
                          SizedBox(width: 4),
                          TextwithFont(
                              text: controller.Foodratinglist[index],
                              size: 15,
                              color: kColorScheme.primary,
                              fontweight: FontWeight.w100),
                        ],
                      ),
                      Spacer(),
                      TextwithFont(
                          text: "qty:${controller.FoodQtylist[index]}",
                          size: 15,
                          color: kColorScheme.primary,
                          fontweight: FontWeight.w100),
                      controller.Foodtypelist[index] == "veg"
                          ? Icon(
                              CupertinoIcons.dot_square,
                              color: vegfoodcolor,
                            )
                          : Icon(
                              CupertinoIcons.dot_square,
                              color: nonvegfoodcolor,
                            ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
