import 'package:flutter/material.dart';
import 'package:auxzonfoodapp/utils/color.dart';
import 'package:get/get.dart';

import '../../../../../controller/WidgetControllers/HomeScreen/Searchbar/SearchBarController.dart';

class SearchBarAnimated extends StatelessWidget {
  SearchBarAnimated({super.key});

  @override
  Widget build(BuildContext context) {
    TextEditingController search = TextEditingController();
    var controller = Get.put(SearchConroler());
    return Obx(() {
      return SizedBox(
        child: AnimatedSwitcher(
          duration: Duration(milliseconds: 300), // Animation duration
          child: controller.displaysearch.value
              ? TextFormField(
                  onChanged: (value) {
                    controller.searchtext.value = value;
                  },
                  controller: search,
                  key: ValueKey('TextFormField'), // Unique key for widget
                  decoration: InputDecoration(
                    suffixIcon: Obx(
                      () => controller.searchtext.value.isNotEmpty
                          ? IconButton(
                              onPressed: () {},
                              icon: Icon(Icons.search),
                            )
                          : IconButton(
                              onPressed: () {
                                controller.Displaysearch(); // Toggle visibility
                              },
                              icon: Icon(Icons.cancel),
                            ),
                    ),
                    hintText: 'Search your hotels',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15)),
                    contentPadding: EdgeInsets.symmetric(horizontal: 10),
                  ),
                )
              : Align(
                  alignment: Alignment.centerLeft,
                  child: Material(
                    key: ValueKey('SearchIcon'), // Unique key for widget
                    elevation: 10,
                    shape: CircleBorder(),
                    child: CircleAvatar(
                      child: IconButton(
                        onPressed: () {
                          controller.Displaysearch(); // Toggle visibility
                          print(
                              "displaysearch.value : ${controller.displaysearch.value}");
                        },
                        icon: Icon(Icons.search),
                      ),
                      backgroundColor: liteColor, // Replace with your liteColor
                    ),
                  ),
                ),
        ),
      );
    });
  }
}
