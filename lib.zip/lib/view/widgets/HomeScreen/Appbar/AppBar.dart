import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../controller/BootomSheetController/Controller/BottomNavgationBarController.dart';
import '../../../../main.dart';
import '../../../../utils/color.dart';

class CustomAppbar extends StatelessWidget {
  const CustomAppbar(
      {super.key,
      required this.image,
      required this.name,
      required this.count});

  final String image;
  final String name;
  final int count;

  @override
  Widget build(BuildContext context) {
    var controller = Get.find<BottomNavigationBarController>();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Material(
        elevation: 10,
        borderRadius: BorderRadius.circular(15),
        child: Container(
          height: MyApp.height * .1,
          width: MyApp.width,
          decoration: BoxDecoration(
              color: kColorSchemelite.primary,
              borderRadius: BorderRadius.circular(15)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset('${image}'),
                  TextwithFont(
                      text: "${name}",
                      size: 24,
                      color: liteColor,
                      fontweight: FontWeight.bold)
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: IconButton(
                  onPressed: () {
                    controller.navcontroller.jumpToTab(1);
                  },
                  icon: Badge.count(
                    count: count,
                    child: Icon(
                      CupertinoIcons.cart,
                      color: liteColor,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
