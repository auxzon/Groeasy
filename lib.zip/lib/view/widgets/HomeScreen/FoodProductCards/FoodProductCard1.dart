import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../controller/ProductDetailsController/ProductDetailsController.dart';
import '../../../../main.dart';
import '../../../../utils/TextFont.dart';
import '../../../../utils/color.dart';
import '../../../Common/ProductDetailsPage/ProductDetailsPage1.dart';

class FoodProductCard1 extends StatelessWidget {
  FoodProductCard1({super.key, required this.controller, required this.index});

  var controller;
  var index;

  @override
  Widget build(BuildContext context) {
    return InkResponse(
      onTap: () {
        Get.delete<Productdetailscontroller>();
        // Navigator.of(context).push(MaterialPageRoute(
        //   builder: (context) => Productdetailspage1(
        //     name: controller.Foodnamelist[index],
        //     image: controller.Foodimglist[index],
        //     rate: double.parse(controller.Foodratelist[index]),
        //     rating: controller.Foodratinglist[index],
        //   ),
        // ));
        Get.to(()=>Productdetailspage1(
          name: controller.Foodnamelist[index],
          image: controller.Foodimglist[index],
          rate: double.parse(controller.Foodratelist[index]),
          rating: controller.Foodratinglist[index],
        ),preventDuplicates: false);
      },
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Stack(
              children: [
                Material(
                  borderRadius: BorderRadius.circular(15),
                  elevation: 10,
                  child: Container(
                    height: MyApp.height * .14,
                    width: MyApp.height * .14,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      image: DecorationImage(
                        fit: BoxFit.cover,
                        image: AssetImage("${controller.Foodimglist[index]}"),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                    child: Row(
                      children: [
                        Icon(
                          Icons.star,
                          color: ratingcolor,
                          size: 14,
                        ),
                        SizedBox(width: 4),
                        // TextwithFont(text: "${controller.Foodratinglist[index]}",
                        //     size: 10.00,
                        //     color: liteColor, fontweight: FontWeight.bold)
                        Text(
                          "${controller.Foodratinglist[index]}",
                          style: Font1.bodyLarge?.copyWith(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: liteColor,
                          ),
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                        ),
                      ],
                    ),
                  ),
                  top: 0,
                ),
                Positioned(
                  child: Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                    child: Text(
                      "Rs.${controller.Foodratelist[index]}",
                      style: Font1.bodyLarge?.copyWith(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: liteColor,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                    ),
                  ),
                  bottom: 0,
                  left: 0,
                ),
              ],
            ),
            Flexible(
              child: SizedBox(
                // color: Colors.blueGrey,
                width: MyApp.height * .14,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "${controller.Foodnamelist[index]}",
                    style: Font1.bodyLarge?.copyWith(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: kColorSchemelite.primary.withOpacity(.8),
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
