import 'package:flutter/material.dart';
import 'package:auxzonfoodapp/view/HotelDetailsScreen/HotelDetailsScreen.dart';
import 'package:get/get.dart';

import '../../../../controller/HomeController/HomeScreenController.dart';
import '../../../../utils/TextFont.dart';
import '../../../../utils/color.dart';

class Hotelproductscard extends StatelessWidget {
  Hotelproductscard({super.key, required this.controller, required this.index});

  final Homescreencontroller controller;
  var index;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Navigator.of(context).push(MaterialPageRoute(
        //   builder: (context) => Hoteldetailsscreen(),
        // ));
        Get.to(() => Hoteldetailsscreen(
          hmController: controller,
              image: controller.Hotelimglist[index],
              name: controller.Hotelnamelist[index],
            ));
      },
      child: Material(
        elevation: 15,
        borderRadius: BorderRadius.circular(15),
        child: Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(15)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                child: Image.asset(controller.Hotelimglist[index]),
              ),
              Expanded(
                child: Text(
                  controller.Hotelnamelist[index],
                  style: Font1.bodyLarge?.copyWith(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: kColorSchemedark.primary,
                  ),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
