import 'package:flutter/material.dart';

import '../../../../main.dart';

class Banner1 extends StatelessWidget {
  const Banner1({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MyApp.height * .2,
      width: MyApp.width,
      margin: EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage("images/1banner.png"),
          )),
    );
  }
}
