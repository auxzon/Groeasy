import 'package:flutter/material.dart';

import '../../../../main.dart';

class Productimage extends StatelessWidget {
  Productimage({super.key, required this.image});
  final String image;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 10,
      borderRadius: BorderRadius.circular(5),
      child: Container(
        height: MyApp.height * .4,
        width: MyApp.width,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage(image),
          ),
        ),
      ),
    );
  }
}
