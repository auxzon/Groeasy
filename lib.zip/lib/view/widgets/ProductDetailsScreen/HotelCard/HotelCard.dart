import 'package:flutter/material.dart';

import '../../../../utils/TextFont.dart';
import '../../../../utils/color.dart';

class Hotelcard extends StatelessWidget {
  const Hotelcard(
      {super.key,
      required this.hotelname,
      required this.hotelloc,
      required this.km});
  final String hotelname;
  final String hotelloc;
  final String km;
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 15,
      child: ListTile(
        title: Text(
          "${hotelname}",
          style: Font1.bodyLarge?.copyWith(
            fontSize: 25,
            fontWeight: FontWeight.bold,
            color: kColorSchemedark.primary,
          ),
        ),
        subtitle: Text(
          "${hotelloc}",
          style: Font1.bodyLarge?.copyWith(
            fontSize: 20,
            fontWeight: FontWeight.w100,
            color: kColorSchemedark.primary,
          ),
        ),
        trailing: Text(
          "${km}",
          style: Font1.bodyLarge?.copyWith(
            fontSize: 15,
            fontWeight: FontWeight.w200,
            color: kColorSchemedark.primary,
          ),
        ),
      ),
    );
  }
}
