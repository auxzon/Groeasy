import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

import '../../../../utils/color.dart';
import '../../../Common/ResultScreen/resultScreen.dart';
import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Addtocartbuttonwidget extends StatelessWidget {
  const Addtocartbuttonwidget({super.key});

  @override
  Widget build(BuildContext context) {
    return FilledButton.tonalIcon(
      onPressed: () {
        Get.to(() => Resultscreen(
            Widgets: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Lottie.asset("images/cartadd.json"),
                  TextwithFont(
                      text: "Item Added To Cart",
                      size: 35,
                      color: kColorScheme.primary,
                      fontweight: FontWeight.w700),
                ],
              ),
            )));
      },
      style: ButtonStyle(
          iconColor: WidgetStatePropertyAll(liteColor),
          backgroundColor: WidgetStatePropertyAll(
            kColorScheme.onPrimaryContainer,
          )),
      label: TextwithFont(
        text: "Add to Cart",
        size: 20.00,
        color: liteColor,
        fontweight: FontWeight.bold,
      ),
      icon: const Icon(Icons.add_shopping_cart),
    );
  }
}
