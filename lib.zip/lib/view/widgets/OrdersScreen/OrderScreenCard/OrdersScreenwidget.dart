import 'package:auxzonfoodapp/controller/WidgetControllers/OrderScreen/OrderScreenCard/OrderScreenCardController.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../controller/OrderScreenController/OrderScreenController.dart';
import '../../../../controller/ProductDetailsController/ProductDetailsController.dart';
import '../../../../main.dart';
import '../../../../utils/color.dart';
import '../../../OrderDetailsScreen/OrderDetailsScreen.dart';
import '../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class OrdersscreenCard extends StatelessWidget {
  const OrdersscreenCard(
      {super.key, required this.controller, required this.index});

  final Orderscreencontroller controller;
  final int index;

  @override
  Widget build(BuildContext context) {
    var cardcontroller = Get.put(OrderScreenCardController());
    return GestureDetector(
      onTap: () {
        cardcontroller.toggleIcon(index); // Pass the tapped card index
      },
      child: Stack(
        children: [
          Card(
            elevation: 20,
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(10),
                  height: MyApp.height >= 890
                      ? MyApp.height * .22
                      : MyApp.height * .2, // Adjusted height slightly
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Container(
                          decoration: BoxDecoration(
                            image: DecorationImage(
                                image:
                                AssetImage(controller.Foodimglist[index]),
                                fit: BoxFit.cover),
                            borderRadius: BorderRadius.circular(15),
                          ),
                          margin: EdgeInsets.only(right: 10),
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextwithFont(
                                text: controller.Hotelnamelist[index],
                                size: 15,
                                maxln: 2,
                                overfloww: TextOverflow.ellipsis,
                                color: kColorScheme.primary,
                                fontweight: FontWeight.w100),
                            Spacer(),
                            TextwithFont(
                                text: controller.Foodnamelist[index],
                                size: 15,
                                color: kColorScheme.primary,
                                fontweight: FontWeight.w900),
                          ],
                        ),
                      ),
                      Spacer(),
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextwithFont(
                                text: "Rs.${controller.Foodratelist[index]}",
                                size: 15,
                                color: kColorScheme.primary,
                                fontweight: FontWeight.w100),
                            Row(
                              children: [
                                Icon(
                                  Icons.star,
                                  color: ratingcolor,
                                  size: 14,
                                ),
                                SizedBox(width: 4),
                                TextwithFont(
                                    text: controller.Foodratinglist[index],
                                    size: 15,
                                    color: kColorScheme.primary,
                                    fontweight: FontWeight.w100),
                              ],
                            ),
                            Spacer(),
                            TextwithFont(
                                text: "qty:${controller.FoodQtylist[index]}",
                                size: 15,
                                color: kColorScheme.primary,
                                fontweight: FontWeight.w100),
                            TextwithFont(
                                text: "${controller.FoodDatelist[index]}",
                                size: 15,
                                color: kColorScheme.primary,
                                fontweight: FontWeight.w100),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Obx(
                      () => AnimatedSwitcher(
                    duration: Duration(milliseconds: 300),
                    transitionBuilder:
                        (Widget child, Animation<double> animation) {
                      return FadeTransition(
                        opacity: animation,
                        child: child,
                      );
                    },
                    child: cardcontroller.selectedIndex.value == index
                        ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextButton.icon(
                          onPressed: () {
                            controller.OrderStaus[index] == "1"
                                ? Get.to(() => Orderproductdetailsdetails(
                                type: "map",
                                name: controller.Foodnamelist[index],
                                image: controller.Foodimglist[index],
                                rate: double.parse(
                                    controller.Foodratelist[index]),
                                hotel: controller.Hotelnamelist[index],
                                rating:
                                controller.Foodratinglist[index]))
                                : ScaffoldMessenger.of(context)
                                .showSnackBar(
                              SnackBar(
                                  content: Text('Item delivered')),
                            );
                          },
                          icon: Icon(Icons.directions),
                          label: TextwithFont(
                            text: "Track",
                            size: 15,
                            color: kColorScheme.primary,
                            fontweight: FontWeight.bold,
                          ),
                        ),
                        TextButton.icon(
                          onPressed: () {
                            Get.to(() => Orderproductdetailsdetails(
                                type: "details",
                                name: controller.Foodnamelist[index],
                                image: controller.Foodimglist[index],
                                hotel: controller.Hotelnamelist[index],
                                rate: double.parse(
                                    controller.Foodratelist[index]),
                                rating:
                                controller.Foodratinglist[index]));
                          },
                          icon: Icon(Icons.shopping_bag_outlined),
                          label: TextwithFont(
                            text: "Details",
                            size: 15,
                            color: kColorScheme.primary,
                            fontweight: FontWeight.bold,
                          ),
                        ),
                      ],
                    )
                        : SizedBox.shrink(),
                  ),
                )
              ],
            ),
          ),
          controller.OrderStaus[index] == "1"
              ? Positioned(
            top: 0.0,
            right: 0.0,
            child: Icon(
              Icons.directions_bike_outlined,
              color: vegfoodcolor,
            ),
          )
              : SizedBox.shrink(),
        ],
      ),
    );
  }
}

