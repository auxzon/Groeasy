import 'package:flutter/material.dart';

import '../../../../../main.dart';
import '../../../../../utils/color.dart';
import '../../../HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class Productdetails extends StatelessWidget {
  const Productdetails({super.key,required this.name,required this.qty,required this.image});
final String name;
final int qty;
final String image;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: TextwithFont(
              text: name,
              size: 20,
              color: kColorScheme.primary,
              fontweight: FontWeight.bold),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: TextwithFont(
              text: "qty : ${qty}",
              size: 15,
              color: kColorScheme.primaryFixedDim,
              fontweight: FontWeight.w100),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(
              vertical: 20, horizontal: 20),
          child: Material(
            elevation: 10,
            borderRadius: BorderRadius.circular(5),
            child: Container(
              width: MyApp.width,
              height: MyApp.height * .2,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  image: DecorationImage(
                      fit: BoxFit.cover, image: AssetImage(image))),
            ),
          ),
        ),
      ],
    );
  }
}
