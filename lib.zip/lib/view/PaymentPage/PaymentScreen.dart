import 'package:auxzonfoodapp/controller/paymentController/PaymentController.dart';
import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:auxzonfoodapp/view/widgets/PayementScreen/PaymentScrAppBar/PaymentScreenAppbar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PaymentScreen extends StatelessWidget {
  PaymentScreen({super.key, required this.rate});

  final int rate;

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(PaymentController());

    // Define the showSnackBar method
    void showSnackBar(BuildContext context, String message, Color color) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            backgroundColor: color,
          ),
        );
      });
    }

    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        children: [
          Paymentscreenappbar(
            vmarg: 0,
            hmarg: 0,
            title: "Payment",
          ),
          const SizedBox(height: 20),
          TextwithFont(
            text: "Total Cost: $rate",
            size: 25,
            color: kColorScheme.onPrimaryFixed,
            fontweight: FontWeight.bold,
          ),
          const SizedBox(height: 20),
          FilledButton.tonalIcon(
            onPressed: () {
              controller.startTransaction();
            },
            label: TextwithFont(
              text: "Pay $rate",
              size: 15,
              color: kColorScheme.primary,
              fontweight: FontWeight.w700,
            ),
            icon: Icon(Icons.payment, color: kColorScheme.primary),
          ),
          const SizedBox(height: 20),

          // Reactive message display using Obx()
          Obx(() {
            if (controller.result.isNotEmpty) {
              return Text(
                controller.result.value,
                style: TextStyle(
                  fontSize: 16,
                  color: controller.status.value == 'SUCCESS'
                      ? Colors.green
                      : Colors.red,
                ),
              );
            }
            return Container(); // Return an empty container if no result
          }),
        ],
      ),

      // Show SnackBar for errors or success feedback
      floatingActionButton: Obx(() {
        if (controller.error.isNotEmpty) {
          showSnackBar(context, controller.error.value, Colors.red);
        }

        if (controller.result.isNotEmpty && controller.status.value == 'SUCCESS') {
          showSnackBar(context, "Payment Successful!", Colors.green);
        }

        return Container(); // Empty container to avoid UI rebuild issues
      }),
    );
  }
}


