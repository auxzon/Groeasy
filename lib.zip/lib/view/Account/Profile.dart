import 'package:auxzonfoodapp/controller/SplashScreenController/SplashScreenController.dart';
import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/MyAccount/MyAccount.dart';
import 'package:auxzonfoodapp/view/Orders/OrdersScreen.dart';
import 'package:auxzonfoodapp/view/SplashScreen/SplashScreen.dart';
import 'package:auxzonfoodapp/view/widgets/AccountScreen/AccountTileCard/AccountTilecard.dart';
import 'package:auxzonfoodapp/view/widgets/AccountScreen/AccountUserCard/AccountuserCard.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class Accountscreeen extends StatelessWidget {
  const Accountscreeen({super.key});

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        SystemNavigator.pop();
      },
      child: BaseScreen(
          child: Stack(
        children: [
          SizedBox(
            height: MyApp.height,
            width: MyApp.width,
            child: Column(
              children: [
                Container(
                  height: MyApp.height * .25,
                  width: MyApp.width,
                  color: kColorScheme.primary,
                  child: Accountusercard(username: "Hi , User"),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 0,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
              height: MyApp.height * .7,
              width: MyApp.width,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15)),
                  ///
                  color: liteColor),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Accounttilecard(
                      icon: Icon(Icons.person),
                      name: "My Account",
                      onTap: () {
                        Get.to(()=>Myaccount());
                      }),
                  Accounttilecard(
                      icon: Icon(Icons.shopping_bag_outlined),
                      name: "Orders",
                      onTap: () {
                        Get.to(()=>Ordersscreen());
                      }),
                  Accounttilecard(
                      icon: Icon(Icons.logout), name: "LogOut",
                      onTap: () {
                        Get.delete<SplashScreenController>();
                        Get.offAll(()=>SplashScrren());
                      }),
                ],
              ),
            ),
          )
        ],
      )),
    );
  }
}
