import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/Orders/OrdersScreen.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:auxzonfoodapp/view/widgets/OrderDetailsScreen/Details/AppBar/OrderScreenAppbar.dart';
import 'package:auxzonfoodapp/view/widgets/OrderDetailsScreen/Details/ProductDetails/ProductDetails.dart';
import 'package:auxzonfoodapp/view/widgets/OrderDetailsScreen/Details/TimeHotelandPrice/OtherDetails.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Orderproductdetailsdetails extends StatelessWidget {
  const Orderproductdetailsdetails(
      {super.key,
      required this.name,
      required this.hotel,
      required this.image,
      required this.rate,
      required this.rating,
      required this.type});

  final String name;
  final String image;
  final double rate;
  final String rating;
  final String type;
  final String hotel;

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
        child: type == "map"
            ? Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Column(
                  children: [
                    OrderDetailsscreenappbar(
                      hmarg: 0,
                      vmarg: 10,
                      title: "Track Order",
                      onTap: () {
                        Get.to(() => Ordersscreen());
                      },
                    ),
                    Expanded(
                        child: Container(
                      color: Colors.red,
                    ))
                  ],
                ),
              )
            : SizedBox(
                height: MyApp.height,
                width: MyApp.width,
                child: ListView(
                  physics: ScrollPhysics(),
                  children: [
                    OrderDetailsscreenappbar(
                      title: "Details",
                      onTap: () {
                        Get.to(() => Ordersscreen());
                      },
                    ),
                    Productdetails(name: name, qty: 55, image: image),
                    Otherdetails(
                        time: 22, loc: "kochi", hotel: hotel, price: 225.00),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: MaterialButton(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        elevation: 10,
                        onPressed: () {},
                        color: kColorScheme.onPrimaryFixed,
                        child: TextwithFont(
                            text: "Cancel Order",
                            size: 20,
                            color: kColorScheme.primaryFixedDim,
                            fontweight: FontWeight.w700),
                      ),
                    )
                  ],
                ),
              ));
  }
}
