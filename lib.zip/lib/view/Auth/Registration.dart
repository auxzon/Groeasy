import 'dart:ui';

import 'package:auxzonfoodapp/view/Auth/LoginScreen.dart';
import 'package:auxzonfoodapp/view/widgets/Auth/RegisterScreen/RegCenterMaterial.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controller/AuthController/AuthController.dart';
import '../../main.dart';
import '../../utils/ScafoldWithsafearea.dart';
import '../../utils/color.dart';
import '../widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';

class RegisterScreen extends StatelessWidget {
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    var controller = Get.find<AuthController>();
    return BaseScreen(
      child: Container(
        height: MyApp.height,
        width: MyApp.width,
        decoration: BoxDecoration(
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage("images/loginbg.jpg"),
          ),
        ),
        child: Center(
          child: Regcentermaterial(
              materialheight: MyApp.height * .7,
              materialwidth: MyApp.width * .9,
              authController: authController,
              materialelevation: 25),
        ),
      ),
    );
  }
}
