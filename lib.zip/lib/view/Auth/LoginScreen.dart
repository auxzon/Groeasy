import 'dart:ui';

import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/view/Auth/Registration.dart';
import 'package:auxzonfoodapp/view/widgets/Auth/LoginScreen/Centermaterial.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controller/AuthController/AuthController.dart';
import '../../utils/color.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var authController = Get.put(AuthController());

    return BaseScreen(
      child: Container(
        height: MyApp.height,
        width: MyApp.width,
        decoration: BoxDecoration(
          image: DecorationImage(
            fit: BoxFit.cover,
            image: AssetImage("images/loginbg.jpg"),
          ),
        ),
        child: Center(
          child: Centermaterial(
            authController: authController,
            materialelevation: 20,
            materialheight: MyApp.height * .6,
            materialwidth: MyApp.width * .9,
          ),
        ),
      ),
    );
  }
}
