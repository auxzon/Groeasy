import 'package:auxzonfoodapp/main.dart';
import 'package:auxzonfoodapp/utils/ScafoldWithsafearea.dart';
import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/Common/ProductDetailsPage/ProductDetailsPage1.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/HomeScreenTextdatas/HomeScreenHeading1.dart';
import 'package:auxzonfoodapp/view/widgets/HomeScreen/SearchBar/view/SearchBarWidget.dart';
import 'package:auxzonfoodapp/view/widgets/HotelDetailsScreen/CustomSliverAppBar/SliverAppBarWidget.dart';
import 'package:auxzonfoodapp/view/widgets/HotelDetailsScreen/ProductCardinHoteldetails/ProductCardinHotelDetailspage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../controller/HomeController/HomeScreenController.dart';

class Hoteldetailsscreen extends StatelessWidget {
  Hoteldetailsscreen(
      {super.key,
      required this.image,
      required this.name,
      required this.hmController});

  var image;
  var name;
  final Homescreencontroller hmController;

  @override
  Widget build(BuildContext context) {
    return BaseScreen(
        child: CustomScrollView(
      slivers: [
        Sliverappbarwidget(name: name, image: image),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20),
            child: SearchBarAnimated(),
          ),
        ),
        SliverList(
            delegate: SliverChildBuilderDelegate(
          childCount: hmController.Foodimglist.length,
          (context, index) => Productcardinhoteldetailspage(
              hmController: hmController, index: index),
        ))
      ],
    ));
  }
}
