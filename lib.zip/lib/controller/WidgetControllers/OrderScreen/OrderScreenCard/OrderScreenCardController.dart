import 'package:get/get.dart';

class OrderScreenCardController extends GetxController {
  var selectedIndex = (-1).obs; // Default value (-1) means no card selected

  void toggleIcon(int index) {
    if (selectedIndex.value == index) {
      // If the selected card is tapped again, collapse it
      selectedIndex.value = -1;
    } else {
      // Otherwise, expand the tapped card
      selectedIndex.value = index;
    }
  }
}
