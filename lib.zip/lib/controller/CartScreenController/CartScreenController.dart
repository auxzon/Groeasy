import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CartScrennController extends GetxController {
  List Foodnamelist = [
    "pasta cheese mixed",
    "pasta (Mint)",
    "Special Burger",
    "Combo Pack",
    "pasta cheese mixed",
    "pasta (Mint)",
    "Special Burger",
    "Combo Pack",
    "pasta cheese mixed",
    "pasta (Mint)",
    "Special Burger",
    "Combo Pack",
  ];
  List FoodQtylist = [
    "1",
    "2",
    "3",
    "4",
    "1",
    "2",
    "3",
    "4",
    "1",
    "2",
    "3",
    "4",
  ];
  List Foodtypelist = [
    "veg",
    "veg",
    "non veg",
    "non veg",
    "veg",
    "veg",
    "non veg",
    "non veg",
    "veg",
    "veg",
    "non veg",
    "non veg",
  ];
  List Foodimglist = [
    "images/food1.jpg",
    "images/food2.jpg",
    "images/food3.jpg",
    "images/food4.jpg",
    "images/food1.jpg",
    "images/food2.jpg",
    "images/food3.jpg",
    "images/food4.jpg",
    "images/food1.jpg",
    "images/food2.jpg",
    "images/food3.jpg",
    "images/food4.jpg",
  ];
  List Hotelnamelist = [
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
  ];
  List Foodratelist = [
    "155",
    "255",
    "355",
    "455",
    "155",
    "255",
    "355",
    "455",
    "155",
    "255",
    "355",
    "455",
  ];

  List Foodratinglist = [
    "4.1",
    "4.2",
    "4.3",
    "4.4",
    "4.1",
    "4.2",
    "4.3",
    "4.4",
    "4.1",
    "4.2",
    "4.3",
    "4.4",
  ];

  ScrollController ListscrollController = ScrollController();
  var atTop = false.obs;
  var atBottom = false.obs;
  @override
  void onInit() async{
    ListscrollController.addListener(() {
      if (ListscrollController.position.pixels >=
          ListscrollController.position.maxScrollExtent) {
          atBottom.value = true;
      } else {
          atBottom.value = false;
      }
    });
    super.onInit();
  }
}
