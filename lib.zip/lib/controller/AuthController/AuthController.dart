import 'package:auxzonfoodapp/utils/color.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../view/Auth/LoginScreen.dart';
import '../../view/Common/BottomSheet/BottomSheet.dart';

class AuthController extends GetxController {
  var isLoading = false.obs;

  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final regemail = TextEditingController();
  final regpasswordController = TextEditingController();
  final regconfirmPasswordController = TextEditingController();

  var showpasslg = false.obs;
  logtogglepass(){
    showpasslg.value = !showpasslg.value;
  }
  var showpassrg = false.obs;
  regtogglepass(){
    showpassrg.value = !showpassrg.value;
  }

  void login() {
    if (_validateLogin()) {
      isLoading.value = true;
      Future.delayed(Duration(seconds: 2), () {
        isLoading.value = false;
        Get.snackbar('Success', 'Login Successful',
        colorText: kColorScheme.surface);
        Get.to(() =>BottomNavigator(index: 0,), transition: Transition.leftToRight);
      });
    }
  }

  void register() {
    if (_validateRegister()) {
      isLoading.value = true;
      Future.delayed(Duration(seconds: 2), () {
        isLoading.value = false;
        Get.snackbar('Success', 'Registration Successful',
            colorText: kColorScheme.surface);
        Get.to(() => LoginScreen());
      });
    }
  }

  bool _validateLogin() {
    if (emailController.text.isEmpty || passwordController.text.isEmpty) {
      Get.snackbar('Error', 'All fields are required',
          colorText: kColorScheme.surface);
      return false;
    }
    return true;
  }

  bool _validateRegister() {
    if (regemail.text.isEmpty || regpasswordController.text.isEmpty || regconfirmPasswordController.text.isEmpty) {
      Get.snackbar('Error', 'All fields are required',
          colorText: kColorScheme.surface);
      return false;
    }
    if (regpasswordController.text != regconfirmPasswordController.text) {
      Get.snackbar('Error', 'Passwords do not match',
          colorText: kColorScheme.surface);
      return false;
    }
    return true;
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    regpasswordController.dispose();
    regemail.dispose();
    regconfirmPasswordController.dispose();
    super.dispose();
  }
}
