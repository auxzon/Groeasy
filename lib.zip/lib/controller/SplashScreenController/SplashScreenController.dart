import 'package:auxzonfoodapp/view/Auth/LoginScreen.dart';
import 'package:get/get.dart';

import '../../view/Common/BottomSheet/BottomSheet.dart';
import '../../view/HomeScreen/HomeScreen.dart';

class SplashScreenController extends GetxController {
  navigatetohome() {
    Future.delayed(
      Duration(seconds: 2),
      () {
        Get.to(() => LoginScreen(), transition: Transition.leftToRight);
      },
    );
  }

  @override
  void onInit() {
    navigatetohome();
    // TODO: implement onInit
    super.onInit();
  }
}
