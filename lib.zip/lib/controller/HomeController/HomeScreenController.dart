import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Homescreencontroller extends GetxController {
  List Hotelimglist = [
    "images/hotel1.jpg",
    "images/hotel2.jpg",
    "images/hotel3.jpg",
    "images/hotel4.jpg",
    "images/hotel1.jpg",
    "images/hotel2.jpg",
    "images/hotel3.jpg",
    "images/hotel4.jpg",
    "images/hotel1.jpg",
    "images/hotel2.jpg",
    "images/hotel3.jpg",
    "images/hotel4.jpg",
    "images/hotel1.jpg",
    "images/hotel2.jpg",
    "images/hotel3.jpg",
    "images/hotel4.jpg",
    "images/hotel1.jpg",
    "images/hotel2.jpg",
    "images/hotel3.jpg",
    "images/hotel4.jpg",
  ];

  List Hotelnamelist = [
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
    "OLD HARBOUR HOTEL",
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
    "OLD HARBOUR HOTEL",
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
    "OLD HARBOUR HOTEL",
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
    "OLD HARBOUR HOTEL",
    "Raintree Multi Cuisine Restaurant",
    "Momo Cafe",
    "Tharavadu Restaurant by Casino hotel",
    "Fort Cochin Seafood Specialty Restaurant",
    "OLD HARBOUR HOTEL",
  ];

  List Foodimglist = [
    "images/food1.jpg",
    "images/food2.jpg",
    "images/food3.jpg",
    "images/food4.jpg",
    "images/food1.jpg",
    "images/food2.jpg",
    "images/food3.jpg",
    "images/food4.jpg",
    "images/food1.jpg",
    "images/food2.jpg",
    "images/food3.jpg",
    "images/food4.jpg",
  ];

  List Foodtypelist = [
    "veg",
    "veg",
    "non veg",
    "non veg",
    "veg",
    "veg",
    "non veg",
    "non veg",
    "veg",
    "veg",
    "non veg",
    "non veg",
  ];

  List Foodnamelist = [
    "pasta cheese mixed",
    "pasta (Mint)",
    "Special Burger",
    "Combo Pack",
    "pasta cheese mixed",
    "pasta (Mint)",
    "Special Burger",
    "Combo Pack",
    "pasta cheese mixed",
    "pasta (Mint)",
    "Special Burger",
    "Combo Pack",
  ];

  List Foodratelist = [
    "155",
    "255",
    "355",
    "455",
    "155",
    "255",
    "355",
    "455",
    "155",
    "255",
    "355",
    "455",
  ];

  List Foodratinglist = [
    "4.1",
    "4.2",
    "4.3",
    "4.4",
    "4.1",
    "4.2",
    "4.3",
    "4.4",
    "4.1",
    "4.2",
    "4.3",
    "4.4",
  ];

  ScrollController scrollController = ScrollController();
  ScrollController ListscrollController = ScrollController();
  var atTop = false.obs;
  var atBottom = false.obs;

  @override
  void onInit() {
    super.onInit();

    // Listen to the GridView's scroll controller
    scrollController.addListener(() {
      if (scrollController.position.atEdge) {
        if (scrollController.position.pixels == 0) {
          // At the top of GridView
          atTop.value = true;
          atBottom.value = false;
          print(
              "You are at the top of GridView: ${atTop.value}, ${atBottom.value}");
        } else {
          // At the bottom of GridView
          atBottom.value = true;
          atTop.value = false;
          print(
              "You are at the bottom of GridView: ${atTop.value}, ${atBottom.value}");
        }
      } else {
        // In between, reset values
        atTop.value = false;
        atBottom.value = false;
        print(
            "GridView scrolling in between: ${atTop.value}, ${atBottom.value}");
      }
    });

    // Listen to the ListView's scroll controller
    ListscrollController.addListener(() {
      // Reset values when scrolling in ListView
      if (ListscrollController.position.atEdge) {
        if (ListscrollController.position.pixels == 0) {
          // At the top of ListView
          print("At the top of ListView");
        } else {
          // At the bottom of ListView
          print("At the bottom of ListView");
        }
      } else {
        // Scrolling in between, reset GridView scroll states
        atTop.value = false;
        atBottom.value = false;
        print("ListView scrolling in between: Resetting GridView states");
      }
    });
  }

  @override
  void onClose() {
    scrollController.dispose();
    ListscrollController.dispose();
    super.onClose();
  }
}
