import 'package:auxzonfoodapp/controller/HomeController/HomeScreenController.dart';
import 'package:auxzonfoodapp/view/HomeScreen/HomeScreen.dart';
import 'package:get/get.dart';
import '../../view/Common/BottomSheet/BottomSheet.dart';
import '../BootomSheetController/Controller/BottomNavgationBarController.dart';

class ResultScreenConntroller extends GetxController {
  @override
  void onInit() {
    super.onInit();
    Retuntopage();
  }

  void Retuntopage() async {
    await Future.delayed(Duration(seconds: 2), () {
      Get.delete<BottomNavigationBarController>();
      Get.delete<Homescreencontroller>();
      Get.to(
          () => BottomNavigator(
                index: 0,
              ),
          transition: Transition.leftToRight);
    });
    Get.delete<ResultScreenConntroller>();
  }
}
