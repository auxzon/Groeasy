import 'package:auxzonfoodapp/utils/color.dart';
import 'package:auxzonfoodapp/view/Account/Profile.dart';
import 'package:auxzonfoodapp/view/Cart/CartScreen.dart';
import 'package:auxzonfoodapp/view/HomeScreen/HomeScreen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';

class BottomNavigationBarController extends GetxController {
  BottomNavigationBarController({required this.index});
  final int index;
  late PersistentTabController navcontroller;

  List<Widget> screens = [
    HomeScreen(),
    Cartscreen(),
    Accountscreeen(),
  ];

  List<PersistentBottomNavBarItem> navItems = [
    PersistentBottomNavBarItem(
      icon: Icon(Icons.home),
      title: ("Home"),
      activeColorPrimary: bottombarselectedcolor,
      inactiveColorPrimary:bottombarnotselectedcolor,
    ),
    PersistentBottomNavBarItem(
      icon: Icon(Icons.card_travel),
      title: ("Cart"),
      activeColorPrimary: bottombarselectedcolor,
      inactiveColorPrimary:bottombarnotselectedcolor,
    ),
    PersistentBottomNavBarItem(
      icon: Icon(Icons.person),
      title: ("Account"),
      activeColorPrimary: bottombarselectedcolor,
      inactiveColorPrimary:bottombarnotselectedcolor,
    ),
  ];

  @override
  void onInit() {
    navcontroller = PersistentTabController(initialIndex: index);
    super.onInit();
  }
}
