import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class ThemeController extends GetxController {
  final _box = GetStorage();
  final _key = 'isDarkMode';

  // Initialize the theme mode from storage, defaulting to false (light theme)
  var isDarkMode = false.obs;

  @override
  void onInit() {
    super.onInit();
    isDarkMode.value = _loadThemeFromStorage(); // Load the theme mode when the controller is initialized
  }

  // Load the theme state from storage
  bool _loadThemeFromStorage() => _box.read(_key) ?? false;

  // Save the theme state to storage
  _saveThemeToStorage(bool isDarkMode) => _box.write(_key, isDarkMode);

  // Method to toggle the theme and persist the state
  void toggleTheme() {
    isDarkMode.value = !isDarkMode.value;
    Get.changeTheme(isDarkMode.value ? ThemeData.dark() : ThemeData.light());
    _saveThemeToStorage(isDarkMode.value);
    print("isDarkMode.value : ${isDarkMode.value}");// Save the updated theme mode to storage
  }
}
